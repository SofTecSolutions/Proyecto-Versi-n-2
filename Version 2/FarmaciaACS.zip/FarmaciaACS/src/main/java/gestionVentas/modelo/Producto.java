package gestionVentas.modelo;

import general.exception.CeroException;
import gestionMedicamentos.modelo.IMedicamento;
import gestionMedicamentos.modelo.Medicamento;

public class Producto implements IProducto {
	private int numProductos;
	private Medicamento medicamento;
	
	//Metodos de Producto
	
	public Producto(Medicamento medicamento) {
		this.medicamento = new Medicamento(medicamento);
		this.numProductos = 1;
	}
	
	public Producto(Producto producto) {
		this.numProductos = producto.getNumProductos();
		this.medicamento = new Medicamento(producto.medicamento);
	}
	
	public void aumentar() {
		numProductos++;
	}
	
	public void disminuir() throws CeroException {
		if(numProductos-1 > 0)
			numProductos--;
		else
			throw new CeroException();
	}
	
	protected Medicamento getMedicamentoTodo() {
		return medicamento;
	}
	
	
	//Metodos de IProducto

	@Override
	public int getNumProductos() {
		return numProductos;
	}

	@Override
	public IMedicamento getMedicamento() {
		return medicamento;
	}

	@Override
	public double subtotal() {
		return numProductos * medicamento.getPrecio();
	}
	
}
