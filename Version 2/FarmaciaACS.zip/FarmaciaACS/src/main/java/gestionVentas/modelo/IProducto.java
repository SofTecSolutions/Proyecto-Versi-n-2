package gestionVentas.modelo;

import gestionMedicamentos.modelo.IMedicamento;

public interface IProducto {
	public int getNumProductos();
	public IMedicamento getMedicamento();
	public double subtotal();
}
