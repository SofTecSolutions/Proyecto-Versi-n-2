package gestionVentas.modelo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import general.exception.*;
import gestionMedicamentos.modelo.Medicamento;

public class Venta implements IVenta {
	private String folio;
	private String fechaCompra;
	private String horaCompra;
	private double subTotal;
	private int descuento;
	private Map<String, Producto> medicamentos;

	private final int LENGTH_FOLIO = 6;
	private final int MAX_VENTAS = (int) Math.pow(10, LENGTH_FOLIO);
	
	
	//Metodos de Venta
	
	public Venta() throws SQLException {
		this.folio = generarFolio();
		this.descuento = 0;
		this.subTotal = 0;
		this.fechaCompra = "";
		this.horaCompra = "";
		this.medicamentos = new HashMap<>();
	}
	
	protected Venta(String folio, String fechaCompra, String horaCompra, double subTotal) {
		this.folio = folio;
		this.fechaCompra = fechaCompra;
		this.horaCompra = horaCompra;
		this.subTotal = subTotal;
		this.medicamentos = new HashMap<>();
	}

	public Venta(Venta venta) {
		this.folio = venta.folio;
		this.fechaCompra = venta.fechaCompra;
		this.horaCompra = venta.horaCompra;
		this.subTotal = venta.subTotal;
		this.descuento = venta.descuento;
		this.medicamentos = new HashMap<>();
		
		for(Producto p: venta.medicamentos.values()) {
			this.medicamentos.put(p.getMedicamento().getId(), new Producto(p) );
		}
		
	}
	
	protected void setProductos(List<Producto> productos) {
		this.medicamentos = new HashMap<>();

		for(Producto p: productos) {
			this.medicamentos.put(p.getMedicamento().getId(), new Producto(p) );
		}
		
	}
	
	public void agregarMedicamento(Medicamento medicamento) {
		if(this.medicamentos.containsKey(medicamento.getId())) {
			Producto p = this.medicamentos.get(medicamento.getId());
			p.aumentar();
		}else
			this.medicamentos.put(medicamento.getId(), new Producto(medicamento));
		subTotal += medicamento.getPrecio();
	}
	
	public void eliminarMedicamento(Medicamento medicamento) throws ProductoException, CeroException {
		if(this.medicamentos.containsKey(medicamento.getId())) {
			Producto p = this.medicamentos.get(medicamento.getId());
			if(p.getNumProductos() == 1)
				this.medicamentos.remove(medicamento.getId());
			else
				p.disminuir();
			subTotal -= medicamento.getPrecio();
		}else
			throw new ProductoException();
	}
	
	public void aplicarDescuento(int descuento) throws NegativeException {
		if(descuento >= 0) 
			this.descuento = descuento;
		else 
			throw new NegativeException();
	}
	
	@SuppressWarnings("deprecation")
	public void generarFechaHora() {
		Date fecha = new Date();
		Calendar c = new GregorianCalendar();
		String cadena = "";
		
		//hora
		if (fecha.getHours() < 10)
			cadena += "0";
		cadena += fecha.getHours() + ":";
		if (fecha.getMinutes() < 10)
			cadena += "0";
		cadena += fecha.getMinutes();
		this.horaCompra = cadena;
		
		//fecha
		cadena = "";
		if (fecha.getDate() < 10)
			cadena += "0";
		cadena += fecha.getDate() + "/";
		if (fecha.getMonth()+1 < 10)
			cadena += "0";
		cadena += (fecha.getMonth()+1) + "/" + c.get(Calendar.YEAR);
		this.fechaCompra = cadena;
	}
	
	private String generarFolio() throws SQLException {
		String folio = "";
		do {
			int folioI = (int) (Math.random() * MAX_VENTAS);
			
			if(folioI >= MAX_VENTAS)
				folioI = MAX_VENTAS - 1;
			
			folio = "" + folioI;
			
			while(folio.length() < LENGTH_FOLIO) {
				folio = "0" + folio;
			}
			
		} while (VentaBD.existe(folio));
		return folio;
	}
	
	public boolean hayProductos() {
		return medicamentos.isEmpty();
	}
	
	//Metodos de IVenta

	@Override
	public String getFolio() {
		return folio;
	}

	@Override
	public String getFechaCompra() {
		return fechaCompra;
	}

	@Override
	public String getHoraCompra() {
		return horaCompra;
	}

	@Override
	public double getSubTotal() {
		double total = descuento;
		total /= 100.0;
		total *= subTotal;
		total = subTotal - total;
		return total;
	}

	@Override
	public int getDescuento() {
		return descuento;
	}

	@Override
	public Iterator<IProducto> getProductos() {
		List<IProducto> productos = new ArrayList<IProducto>();
		
		for(Producto p: this.medicamentos.values()) {
			productos.add(new Producto(p));
		}
		
		return productos.iterator();
	}
	
}
