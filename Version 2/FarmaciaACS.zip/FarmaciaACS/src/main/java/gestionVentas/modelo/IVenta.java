package gestionVentas.modelo;

import java.util.Iterator;

public interface IVenta {
	public String getFolio();
	public String getFechaCompra();
	public String getHoraCompra();
	public double getSubTotal();
	public int getDescuento();
	public Iterator<IProducto> getProductos();
}
