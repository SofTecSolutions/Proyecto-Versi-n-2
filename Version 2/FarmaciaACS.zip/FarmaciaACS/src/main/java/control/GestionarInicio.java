package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import general.exception.CaracterException;
import general.exception.CeroException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;
import general.modelo.AdminBD;
import general.modelo.Farmacia;
import general.modelo.IFarmacia;
import gestionVendedores.modelo.IVendedor;
import gestionVentas.modelo.Venta;

/**
 * Servlet implementation class GestionarInicio
 */
@WebServlet("/GestionarInicio")
public class GestionarInicio extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionarInicio() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        
        HttpSession session = request.getSession();
        String menssage = "";
        
        String correo = request.getParameter("correo");
        String password = request.getParameter("password");
        
        try {
        	
            System.out.println("inicio");
        	IFarmacia farmacia = new Farmacia(AdminBD.cargar());
        	
        	if(correo.equals("admin@farmaciACS.com")) {
				if(password.equals(farmacia.getPassword())) {
					session.setAttribute("farmacia", farmacia);
					request.getRequestDispatcher("GestionarVendedores").forward(request, response);
				}else {
					menssage = "Contraseña incorecta";
					request.setAttribute("message", menssage);
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}

            }else {
            	Optional<IVendedor> vendedor = farmacia.obtenerVendedor(correo, password);
            	
            	if(vendedor.isPresent()) {
            		session.setAttribute("vendedor", vendedor.get());
            		Venta venta = new Venta();
            		session.setAttribute("venta", venta);
					request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
            	}else {
					menssage = "Correo o contraseña incorecta";
					request.setAttribute("message", menssage);
					request.getRequestDispatcher("index.jsp").forward(request, response);
            	}
            	
            }
		} catch (SQLException | LengthException | NegativeException | PalabraException | CaracterException | CeroException | RangoException e) {

			e.printStackTrace();
			String messages = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", messages);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		} 
        
	}

}
