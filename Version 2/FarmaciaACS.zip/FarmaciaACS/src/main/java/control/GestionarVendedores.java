package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import general.exception.CaracterException;
import general.exception.CeroException;
import general.exception.FechaException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;
import general.modelo.Direccion;
import general.modelo.Farmacia;
import general.modelo.IFarmacia;
import gestionVendedores.modelo.Vendedor;
import gestionVendedores.modelo.VendedorBD;
import gestionVentas.modelo.Venta;
import gestionVentas.modelo.VentaBD;

/**
 * Servlet implementation class GestionarVendedores
 */
@WebServlet("/GestionarVendedores")
public class GestionarVendedores extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionarVendedores() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        HttpSession session = request.getSession();
        IFarmacia farmacia = (IFarmacia) session.getAttribute("farmacia");
        if(farmacia == null)
        	farmacia = new Farmacia();
        
        String[] message;
        
        String boton = request.getParameter("boton");
        
        System.out.println(boton);
        
        if(boton != null)
	        switch (boton) {
	        //Botones de Administrador.jsp
			case "BN":
				message = new String[14];
				for(int i=0; i<message.length; i++)
					message[i] = "";
				request.setAttribute("message", message);
				request.getRequestDispatcher("GestionVendedor/NuevoVendedor.jsp").forward(request, response);
				break;
			case "BD":
				if(buscarVendedor(request, response, farmacia, session)) {
					request.getRequestDispatcher("GestionVendedor/InfoVendedor.jsp").forward(request, response);
				}else {
					regresar(request, response, farmacia,session);
				}
				break;
	
			case "BA":
				if(buscarVendedor(request, response, farmacia, session)) {
					message = new String[14];
					for(int i=0; i<message.length; i++)
						message[i] = "";
					request.setAttribute("message", message);
					request.getRequestDispatcher("GestionVendedor/ActualizarVendedor.jsp").forward(request, response);
				}else {
					regresar(request, response, farmacia,session);
				}
				break;
	
			case "BE":
				if(buscarVendedor(request, response, farmacia, session)) {
					request.getRequestDispatcher("GestionVendedor/EliminarVendedor.jsp").forward(request, response);
				}else {
					regresar(request, response, farmacia,session);
				}
				break;
				
			//Botones de InfoVendedor.jsp	
			case "DA":
				message = new String[14];
				for(int i=0; i<message.length; i++)
					message[i] = "";
				request.setAttribute("message", message);
				request.getRequestDispatcher("GestionVendedor/ActualizarVendedor.jsp").forward(request, response);
				break;
			case "DE":
				request.getRequestDispatcher("GestionVendedor/EliminarVendedor.jsp").forward(request, response);
				break;
			case "V":
					regresarVenta(request, response, farmacia, session);
				break;
			case "BDV":
				if(buscarVenta(request, response, farmacia, session)) {
					request.getRequestDispatcher("GestionVenta/InfoVenta.jsp").forward(request, response);
				}else {
					regresarVenta(request, response, farmacia,session);
				}
			break;
			case "BEV":
				if(buscarVenta(request, response, farmacia, session)) {
					request.getRequestDispatcher("GestionVenta/EliminarVenta.jsp").forward(request, response);
				}else {
					regresarVenta(request, response, farmacia,session);
				}
			break;
			case "DVE":
				request.getRequestDispatcher("GestionVenta/EliminarVenta.jsp").forward(request, response);
			break;
			case "EVV":
				eliminarVenta(request, response, farmacia, session);
			break;
			
			//Botones de accion
			case "NV":
				nuevoVendedor(request, response, farmacia,session);
				break;
				
			case "AV":
				actualizarVendedor(request, response,farmacia,session);
				break;
	
			case "EV":
				eliminarVendedor(request, response,farmacia,session);
				break;

			case "C":
	        	regresar(request, response, farmacia,session);
				break;
				
			//Botones para administrar venta
				
			default:
				break;
			}
        else {
        	regresar(request, response, farmacia,session);
        }
        
	}
	
	protected boolean buscarVendedor(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia, HttpSession session)  throws ServletException, IOException {
		boolean result = false;
		String message = "";
		String numEmpleado = request.getParameter("numEmpleado");
		if(numEmpleado != null) {
			try {
				Optional<Vendedor> vendedor = VendedorBD.buscar(numEmpleado);
				if(vendedor.isPresent()) {
					session.setAttribute("vendedor", vendedor.get());
					result = true;
				}else {
					message = "Empleado no encontrado";
					request.setAttribute("message", message);
					regresar(request, response, farmacia,session);
				}
			} catch (SQLException | NegativeException | LengthException | PalabraException | CaracterException
					| CeroException | RangoException e) {
				
			}
		}else {
			message = "No se pudo buscar al vendedor";
			request.setAttribute("message", message);
			regresar(request, response, farmacia,session);
		}
		return result;
	}
	
	protected void regresar(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		try {
			session.setAttribute("vendedores", farmacia.getVendedores());
			request.getRequestDispatcher("GestionVendedor/Administrador.jsp").forward(request, response);
		} catch (SQLException | LengthException | NegativeException | PalabraException | CaracterException | CeroException | RangoException e) {

			e.printStackTrace();
			String messages = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", messages);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

	protected boolean buscarVenta(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia, HttpSession session)  throws ServletException, IOException {
		boolean result = false;
		String message = "";
		String folio = request.getParameter("folio");
		if(folio != null) {
			try {
				Optional<Venta> venta = VentaBD.buscar(folio);
				if(venta.isPresent()) {
					session.setAttribute("venta", venta.get());
					result = true;
				}else {
					message = "Empleado no encontrado";
					request.setAttribute("message", message);
					regresarVenta(request, response, farmacia,session);
				}
			} catch (SQLException | NegativeException | PalabraException  | FechaException e) {

				e.printStackTrace();
				String messages = "Ha ocurrido un problema de conexión";
				request.setAttribute("message", messages);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}else {
			message = "No se pudo buscar la venta";
			request.setAttribute("message", message);
			regresarVenta(request, response, farmacia,session);
		}
		return result;
	}
	
	protected void regresarVenta(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		try {
			Vendedor vendedor = (Vendedor) session.getAttribute("vendedor");
			session.setAttribute("ventas",vendedor.getVentas() );
			request.getRequestDispatcher("GestionVenta/Ventas.jsp").forward(request, response);
		} catch (SQLException | NegativeException | PalabraException | FechaException e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
	
	protected void nuevoVendedor(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		boolean crear = true;
		String[] message = new String[14];
		for(int i=0; i<message.length; i++)
			message[i] = "";
		Direccion direccion = null;
		Vendedor vendedor = null;

		String primerNombre = request.getParameter("Nombre"); //0
		String segundoNombre = request.getParameter("SegundoNombre");//1
		String apellidoPaterno = request.getParameter("ApellidoPaterno");//2
		String apellidoMaterno = request.getParameter("ApellidoMaterno");//3
		int edad = 0;
		try {
			edad = Integer.parseInt(request.getParameter("Edad"));//4
		} catch (NumberFormatException e) {
			message[4] = "No ha ingresado una edad"; 
		}
		String numeroTelefono = request.getParameter("NumeroTelefono");//5
		String calle = request.getParameter("Calle");//6
		String numExterior = request.getParameter("NumExterno");//7
		String numInterior = request.getParameter("NumInterno");//8
		String colonia = request.getParameter("Colonia");//9
		String ciudad = request.getParameter("Alcaldia");//10
		String estado = request.getParameter("Estado");//11
		String codigoPostal = request.getParameter("CodigoPostal");//12
		double sueldo = -1;
		try {
			sueldo = Double.parseDouble(request.getParameter("Sueldo"));//13
		} catch (NumberFormatException e) {
			message[13] = "No ha ingresado una cantidad"; 
		}
		
		//Intentamos crear la Direccion
		direccion = new Direccion();
		try {
			direccion.setCalle(calle.toUpperCase());
		} catch (PalabraException e) {
			message[6] = e.getMessage();
		}
		try {
			direccion.setNumExterior(numExterior.toUpperCase());
		} catch (CaracterException e) {
			message[7] = e.getMessage();
		}
		try {
			direccion.setNumInterior(numInterior.toUpperCase());
		} catch (CaracterException e) {
			message[8] = e.getMessage();
		}
		try {
			direccion.setColonia(colonia.toUpperCase());
		} catch (PalabraException e) {
			message[9] = e.getMessage();
		}
		try {
			direccion.setCiudad(ciudad.toUpperCase());
		} catch (PalabraException e) {
			message[10] = e.getMessage();
		}
		try {
			direccion.setEstado(estado.toUpperCase());
		} catch (PalabraException e) {
			message[11] = e.getMessage();
		}
		try {
			direccion.setCodigoPostal(codigoPostal.toUpperCase());
		} catch (CaracterException e) {
			message[12] = e.getMessage();
			e.printStackTrace();
		} catch (LengthException e) {
			message[12] = e.getMessage();
		}
		
		//Intentamos crear la Persona
		try {
			vendedor = new Vendedor();
			try {
				vendedor.setPrimerNombre(primerNombre.toUpperCase());
			} catch (PalabraException e) {
				message[0] = e.getMessage();
			}
			try {
				vendedor.setSegundoNombre(segundoNombre.toUpperCase());
			} catch (PalabraException e) {
				message[1] = e.getMessage();
			}
			try {
				vendedor.setApellidoPaterno(apellidoPaterno.toUpperCase());
			} catch (PalabraException e) {
				message[2] = e.getMessage();
			}
			try {
				vendedor.setApellidoMaterno(apellidoMaterno.toUpperCase());
			} catch (PalabraException e) {
				message[3] = e.getMessage();
			}
			try {
				vendedor.setEdad(edad);
			} catch (NegativeException e) {
				message[4] = e.getMessage();
			} catch (RangoException e) {
				message[4] = e.getMessage();
			}
			try {
				vendedor.setNumeroTelefono(numeroTelefono);
			} catch (LengthException e) {
				message[5] = e.getMessage();
			} catch (CaracterException e) {
				message[5] = e.getMessage();
			}
			
			//Intentamos crear al Vendedor
			try {
				vendedor.setSueldo(sueldo);
			} catch (NegativeException e) {
				message[13] = e.getMessage();
			}
			
		} catch (SQLException e) {
			
		}
		
		for(String s: message) {
			if(!s.equals("")) {
				crear = false;
				break;
			}
		}
		
		if(crear) {
			try {
				String mensaje = "";
				vendedor.generarCorreo();
				vendedor.setDireccion(direccion);
				
				if(VendedorBD.guardar(vendedor)) {
					mensaje = "Se creado correctamente al vendedor con número de empleado: " + vendedor.getNumEmpleado();
					request.setAttribute("message", mensaje);
					regresar(request, response, farmacia,session);
				}else {
					mensaje = "No se pudo crear al empleado";
					request.setAttribute("message", mensaje);
					regresar(request, response, farmacia,session);
				}
				
			} catch (SQLException | LengthException e) {
				
			}
		}else {
			request.setAttribute("message", message);
			request.getRequestDispatcher("GestionVendedor/NuevoVendedor.jsp").forward(request, response);
		}
		
	}

	protected void actualizarVendedor(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		boolean crear = true;
		String[] message = new String[14];
		for(int i=0; i<message.length; i++)
			message[i] = "";
		Vendedor vendedor = new Vendedor((Vendedor) session.getAttribute("vendedor"));
		Direccion direccion = new Direccion(vendedor.getDireccion());

		String primerNombre = request.getParameter("Nombre"); //0
		String segundoNombre = request.getParameter("SegundoNombre");//1
		String apellidoPaterno = request.getParameter("ApellidoPaterno");//2
		String apellidoMaterno = request.getParameter("ApellidoMaterno");//3
		String edadS = request.getParameter("Edad");
		int edad = 0;
		if(!edadS.equals("")) {
			try {
				edad = Integer.parseInt(edadS);//4
			} catch (NumberFormatException e) {
				message[4] = "No ha ingresado una edad"; 
			}
		}
		String numeroTelefono = request.getParameter("NumeroTelefono");//5
		String calle = request.getParameter("Calle");//6
		String numExterior = request.getParameter("NumExterno");//7
		String numInterior = request.getParameter("NumInterno");//8
		String colonia = request.getParameter("Colonia");//9
		String ciudad = request.getParameter("Alcaldia");//10
		String estado = request.getParameter("Estado");//11
		String codigoPostal = request.getParameter("CodigoPostal");//12
		String sueldoS = request.getParameter("Sueldo");
		double sueldo = -1;
		if(!sueldoS.equals("")) {
			try {
				sueldo = Double.parseDouble(sueldoS);//13
			} catch (NumberFormatException e) {
				message[13] = "No ha ingresado una cantidad"; 
			}
		}
		
		//direccion
		try {
			if(!primerNombre.equals(""))
				direccion.setCalle(calle.toUpperCase());
		} catch (PalabraException e) {
			message[6] = e.getMessage();
		}
		try {
			if(!numExterior.equals(""))
				direccion.setNumExterior(numExterior.toUpperCase());
		} catch (CaracterException e) {
			message[7] = e.getMessage();
		}
		try {
			if(!numInterior.equals(""))
				direccion.setNumInterior(numInterior.toUpperCase());
		} catch (CaracterException e) {
			message[8] = e.getMessage();
		}
		try {
			if(!colonia.equals(""))
				direccion.setColonia(colonia.toUpperCase());
		} catch (PalabraException e) {
			message[9] = e.getMessage();
		}
		try {
			if(!ciudad.equals(""))
				direccion.setCiudad(ciudad.toUpperCase());
		} catch (PalabraException e) {
			message[10] = e.getMessage();
		}
		try {
			if(!estado.equals("Sin cambios"))
				direccion.setEstado(estado.toUpperCase());
		} catch (PalabraException e) {
			message[11] = e.getMessage();
		}
		try {
			if(!codigoPostal.equals(""))
				direccion.setCodigoPostal(codigoPostal.toUpperCase());
		} catch (CaracterException e) {
			message[12] = e.getMessage();
			e.printStackTrace();
		} catch (LengthException e) {
			message[12] = e.getMessage();
		}

		//datos personales
		try {
			if(!primerNombre.equals(""))
				vendedor.setPrimerNombre(primerNombre.toUpperCase());
		} catch (PalabraException e) {
			message[0] = e.getMessage();
		}
		try {
			if(!segundoNombre.equals(""))
				vendedor.setSegundoNombre(segundoNombre.toUpperCase());
		} catch (PalabraException e) {
			message[1] = e.getMessage();
		}
		try {
			if(!apellidoPaterno.equals(""))
				vendedor.setApellidoPaterno(apellidoPaterno.toUpperCase());
		} catch (PalabraException e) {
			message[2] = e.getMessage();
		}
		try {
			if(!apellidoMaterno.equals(""))
				vendedor.setApellidoMaterno(apellidoMaterno.toUpperCase());
		} catch (PalabraException e) {
			message[3] = e.getMessage();
		}
		try {
			if(!edadS.equals(""))
				vendedor.setEdad(edad);
		} catch (NegativeException e) {
			message[4] = e.getMessage();
		} catch (RangoException e) {
			message[4] = e.getMessage();
		}
		try {
			if(!numeroTelefono.equals(""))
				vendedor.setNumeroTelefono(numeroTelefono);
		} catch (LengthException e) {
			message[5] = e.getMessage();
		} catch (CaracterException e) {
			message[5] = e.getMessage();
		}
		
		//Intentamos crear al Vendedor
		try {
			if(!sueldoS.equals(""))
				vendedor.setSueldo(sueldo);
		} catch (NegativeException e) {
			message[13] = e.getMessage();
		}
		

		for(String s: message) {
			if(!s.equals("")) {
				crear = false;
				break;
			}
		}
		
		if(crear) {	
			try {
				String mensaje = "";
				vendedor.setDireccion(direccion);
				
				if(VendedorBD.actualizar(vendedor)) {
					mensaje = "Se actualizaron correctamente los detos del vendedor con número de empleado: " + vendedor.getNumEmpleado();
					request.setAttribute("message", mensaje);
					regresar(request, response, farmacia,session);
				}else {
					mensaje = "No se pudo actualizar al empleado";
					request.setAttribute("message", mensaje);
					regresar(request, response, farmacia,session);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}else {
			request.setAttribute("message", message);
			request.getRequestDispatcher("GestionVendedor/ActualizarVendedor.jsp").forward(request, response);
		}
		
	}

	protected void eliminarVendedor(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		Vendedor vendedor = (Vendedor) session.getAttribute("vendedor");
		String message;
		
		try {
			if(VendedorBD.eliminar(vendedor.getNumEmpleado())) {
				message = "Se ha eliminado correctamente al vendedor con número de empleado: " + vendedor.getNumEmpleado();
				request.setAttribute("message", message);
				regresar(request, response, farmacia,session);
			}else {
				message = "No se pudo eliminar al empleado";
				request.setAttribute("message", message);
				regresar(request, response, farmacia,session);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	protected void eliminarVenta(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		Venta venta = (Venta) session.getAttribute("venta");
		String message;
		
		try {
			if(VentaBD.eliminar(venta.getFolio())) {
				message = "Se ha eliminado correctamente la venta con folio: " + venta.getFolio();
				request.setAttribute("message", message);
				regresarVenta(request, response, farmacia,session);
			}else {
				message = "No se pudo eliminar la venta";
				request.setAttribute("message", message);
				regresarVenta(request, response, farmacia,session);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			String messages = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", messages);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
	

}
