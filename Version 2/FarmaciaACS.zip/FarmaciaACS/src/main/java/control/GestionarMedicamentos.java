package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;
import java.util.List;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import general.exception.FechaException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.modelo.Farmacia;
import general.modelo.IFarmacia;
import gestionMedicamentos.modelo.Medicamento;
import gestionMedicamentos.modelo.Componente;
import gestionMedicamentos.modelo.ComponenteBD;
import gestionMedicamentos.modelo.MedicamentoBD;
import gestionMedicamentos.modelo.ViaAdministracion;

/**
 * Servlet implementation class GestionarMedicamentos
 */
@WebServlet("/GestionarMedicamentos")
public class GestionarMedicamentos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionarMedicamentos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        IFarmacia farmacia = (IFarmacia) session.getAttribute("farmacia");
        if(farmacia == null)
        	farmacia = new Farmacia();
        
        String[] message;
        String mensaje = "";
        List<String> list;
        
        String boton = request.getParameter("boton");
        
        System.out.println(boton);
        /* BN - BOTÓN QUE ENVIA A NUEVO MEDICAMENTO
         * BA - BOTÓN QUE ENVIA A ACTUALIZAR MEDICAMENTO
         * BD - BOTÓN QUE ENVIA A INFO MEDICAMENTO
         * BE - BOTÓN QUE ENVIA A ELIMINAR MEDICAMENTO
         * 
         * DA - ENVIA DE INFO MEDICAMENTO A ACTUALIZAR MEDICAMENTO
         * DE - ENVIA DE INFO MEDICAMENTO A ELIMINAR MEDICAMENTO
         * DM - FUNCION AGREGAR EXISTENCIA
         * 
         * NM - FUNCION NUEVO MEDICAMENTO
         * CNM - FUNCION CONTINUAR CREACION MEDICAMENTO
         * MAC - FUNCION AGREGAR COMPONENTE A MEDICAMENTO
         * MEC - FUNCION QUITAR COMPONENTE A MEDICAMENTO
         * AM - FUNCION ACTUALIZAR MEDICAMENTO
         * CAM - FUNCION CONTINUAR ACTUALIZACION MEDICAMENTO
         * AAC - FUNCION AGREGAR COMPONENTE A MEDICAMENTO A ACTUALIZAR
         * AEC - FUNCION QUITAR COMPONENTE A MEDICAMENTO A ACTUALIZAR
         * EM - FUNCION ELIMINAR MEDICAMENTO
         * 
         * BNC - BOTÓN QUE ENVIA A NUEVO COMPONENTE
         * BAC - BOTÓN QUE ENVIA A ACTUALIZAR COMPONENTE
         * BDC - BOTÓN QUE ENVIA A INFO COMPONENTE
         * BEC - BOTÓN QUE ENVIA A ELIMINAR COMPONENTE
         * 
         * DA - ENVIA DE INFO CONPONENTE A ACTUALIZAR CONPONENTE
         * DE - ENVIA DE INFO CONPONENTE A ELIMINAR CONPONENTE
         * 
         * NC - FUNCION NUEVO COMPONENTE
         * AC - FUNCION ACTUALIZAR COMPONENTE
         * EC - FUNCION ELIMINAR COMPONENTE
         * 
         * CC - ENVIA/REGRESA A GESTIONAR COMPONENTE 
         * C - ENVIA/REGRESA A GESTIONAR MEDICAMENTO
         **/
        if(boton != null)
	        switch (boton) {
	        //Botones de GestionarClientes.jsp
			case "BN":
				message = new String[4];
				for(int i=0; i<message.length; i++)
					message[i] = "";
				request.setAttribute("message", message);
				list = ViaAdministracion.valores();
				request.setAttribute("vias",list);
				request.getRequestDispatcher("GestionMedicamento/NuevoMedicamento.jsp").forward(request, response);
				break;
			case "BD":
				if(buscarMedicamento(request, response,farmacia, session)) {
					request.getRequestDispatcher("GestionMedicamento/InfoMedicamento.jsp").forward(request, response);
				}else {
					regresar(request, response, farmacia,session);
				}
				break;
	
			case "BA":
				if(buscarMedicamento(request, response,farmacia, session)) {
					message = new String[4];
					for(int i=0; i<message.length; i++)
						message[i] = "";
					request.setAttribute("message", message);
					list = ViaAdministracion.valores();
					request.setAttribute("vias",list);
					request.getRequestDispatcher("GestionMedicamento/ActualizarMedicamento.jsp").forward(request, response);
				}else {
					regresar(request, response, farmacia,session);
				}
				break;
	
			case "BE":
				if(buscarMedicamento(request, response,farmacia, session)) {
					request.getRequestDispatcher("GestionMedicamento/EliminarMedicamento.jsp").forward(request, response);
				}else {
					regresar(request, response, farmacia,session);
				}
				break;

				
			//Botones de InfoMedicamento	
			case "DA":
				message = new String[4];
				for(int i=0; i<message.length; i++)
					message[i] = "";
				request.setAttribute("message", message);
				list = ViaAdministracion.valores();
				request.setAttribute("vias",list);
				request.getRequestDispatcher("GestionMedicamento/ActualizarMedicamento.jsp").forward(request, response);
				break;
			case "DE":
				request.getRequestDispatcher("GestionMedicamento/EliminarMedicamento.jsp").forward(request, response);
				break;

			case "DM":
				actualizarExistencia(request, response, session);
				break;

			
			//Botones de accion que administran los medicamentos
			case "NM":
				nuevoMedicamentoContinuar(request, response, farmacia, session);
				break;

			case "CNM":
				nuevoMedicamento(request, response, farmacia, session);
				break;

			case "MAC":
				agregarComponente(request, response, farmacia, session);
				break;

			case "MEC":
				quitarComponente(request, response, farmacia, session);
				break;
	
			case "AM":
				actualizarMedicamentoContinuar(request, response, farmacia, session);
				break;

			case "CAM":
				actualizarMedicamento(request, response, farmacia, session);
				break;

			case "AAC":
				agregarComponenteActualizar(request, response, farmacia, session);
				break;

			case "AEC":
				quitarComponenteActualizar(request, response, farmacia, session);
				break;
	
			case "EM":
				eliminarMedicamento(request, response, farmacia, session);
				break;

				
				
			//BOTONES DE GESTION COMPONENTE

			case "BNC":
				mensaje = "";
				request.setAttribute("message", mensaje);
				request.getRequestDispatcher("GestionMedicamento/NuevoComponente.jsp").forward(request, response);
				break;

			case "BAC":
				if(buscarComponente(request, response,farmacia, session)) {
					mensaje = "";
					request.setAttribute("message", mensaje);
					request.getRequestDispatcher("GestionMedicamento/ActualizarComponentes.jsp").forward(request, response);
				}else {
					regresarComponente(request, response, farmacia,session);
				}
				break;

			case "BDC":
				if(buscarComponente(request, response,farmacia, session)) {
					request.getRequestDispatcher("GestionMedicamento/InfoComponentes.jsp").forward(request, response);
				}else {
					regresarComponente(request, response, farmacia, session);
				}
				break;

			case "BEC":
				if(buscarComponente(request, response,farmacia, session)) {
					request.getRequestDispatcher("GestionMedicamento/EliminarComponentes.jsp").forward(request, response);
				}else {
					regresarComponente(request, response, farmacia,session);
				}
				break;
				
				
			//BOTONES DE INFO COMPONENTES
			
			case "DAC":
				mensaje = "";
				request.setAttribute("message", mensaje);
				request.getRequestDispatcher("GestionMedicamento/ActualizarComponentes.jsp").forward(request, response);
				break;

			case "DEC":
				request.getRequestDispatcher("GestionMedicamento/EliminarComponentes.jsp").forward(request, response);
			break;
				

				
			//BOTONES DE ACCION DE PARA ADMINISTRAR COMPONENTES

			case "NC":
				nuevoComponente(request, response, farmacia, session);
				break;

			case "AC":
				actualizarComponente(request, response, farmacia, session);
				break;

			case "EC":
				eliminarComponente(request, response, farmacia, session);
				break;

				
			//Botones de regreso

			case "C":
	        	regresar(request, response, farmacia,session);
				break;

			case "CC":
	        	regresarComponente(request, response, farmacia,session);
				break;
				
			default:
				break;
			}
        else {
        	regresar(request, response, farmacia,session);
        }
        
	}
	
	
	//Metodos para gestionar Medicamento
	protected boolean buscarMedicamento(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia, HttpSession session)  throws ServletException, IOException {
		boolean result = false;
		String message = "";
		String id = request.getParameter("id");
		if(id != null) {
			try {
				Optional<Medicamento> medicamento = MedicamentoBD.buscar(id);
				if(medicamento.isPresent()) {
					session.setAttribute("medicamento", medicamento.get());
					result = true;
				}else {
					String mensaje = "Medicamento no encontrado";
					request.setAttribute("message", mensaje);
					regresar(request, response, farmacia,session);
				}
			} catch (SQLException | NegativeException | PalabraException | FechaException e) {
				e.printStackTrace();
				String messages = "Ha ocurrido un problema de conexión";
				request.setAttribute("message", messages);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}else {
			message = "No se pudo buscar al medicamento";
			request.setAttribute("message", message);
			regresar(request, response, farmacia,session);
		}
		return result;
	}
	
	protected void regresar(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		try {
			session.setAttribute("medicamentos", farmacia.getMedicamentos());
			request.getRequestDispatcher("GestionMedicamento/GestionMedicamentos.jsp").forward(request, response);
		} catch (SQLException | NegativeException | PalabraException  | FechaException e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

	protected void regresarAgregarMedicamento(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		try {
			request.setAttribute("componentes", farmacia.getComponentes());
			request.getRequestDispatcher("GestionMedicamento/MedicamentoComponente.jsp").forward(request, response);
		} catch (SQLException  | PalabraException   e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

	protected void regresarActualizarMedicamento(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		try {
			request.setAttribute("componentes", farmacia.getComponentes());
			request.getRequestDispatcher("GestionMedicamento/MedicamentoComponenteActualizar.jsp").forward(request, response);
		} catch (SQLException  | PalabraException   e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
	
	protected void nuevoMedicamento(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		boolean crear = true;
		String[] message = new String[4];
		for(int i=0; i<message.length; i++)
			message[i] = "";
		Medicamento medicamento = null;

		String nombre = request.getParameter("NombreMedicamento"); //0
		String viaAdministracion = request.getParameter("ViaAdministracion");
		String fecha = request.getParameter("FechaCaducidad");//1
		double precio = -1;
		try {
			precio = Double.parseDouble(request.getParameter("Precio"));//2
		} catch (NumberFormatException e) {
			message[2] = "No ha ingresado una cantidad"; 
		}
		
		//reacomodamos fecha
		String[] fechaToken = fecha.split("-");
		String fechaCaducidad = "";
		if(fechaToken.length == 3)
			fechaCaducidad = fechaToken[2] + "/" + fechaToken[1] + "/" + fechaToken[0];
		
		//Intentamos crear la Medicamento
		try {
			medicamento = new Medicamento();
			try {
				medicamento.setNombre(nombre.toUpperCase());
			} catch (PalabraException e) {
				message[0] = e.getMessage();
			}
			if(!viaAdministracion.equals("")) {
				medicamento.setViaAdministracion(viaAdministracion.toUpperCase());
			}else {
				message[3] = "Escoje una via de administracion valida";
			}
			try {
				medicamento.setFechaCaducidad(fechaCaducidad.toUpperCase());
			} catch (FechaException e) {
				message[1] = e.getMessage();
			} catch (PalabraException e) {
				message[1] = e.getMessage();
			}
			try {
				medicamento.setPrecio(precio);
			} catch (NegativeException e) {
				message[2] = e.getMessage();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			String messages = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", messages);
			request.getRequestDispatcher("index.jsp").forward(request, response);
			
		}
		
		for(String s: message) {
			if(!s.equals("")) {
				crear = false;
				break;
			}
		}
		
		if(crear) {
			session.setAttribute("medicamento", medicamento);
			regresarAgregarMedicamento(request, response, farmacia, session);
		}else {
			request.setAttribute("message", message);
			List<String> list = ViaAdministracion.valores();
			request.setAttribute("vias",list);
			request.getRequestDispatcher("GestionMedicamento/NuevoMedicamento.jsp").forward(request, response);
		}
	}
	
	protected void nuevoMedicamentoContinuar(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		Medicamento medicamento = (Medicamento) session.getAttribute("medicamento");
		
		int cont = 0;
		Iterator<Componente> componentes = medicamento.getComponentes();
		while(componentes.hasNext()) {
			componentes.next();
			cont++;
		}
		
		if(cont>0) {
			try {
				if(MedicamentoBD.guardar(medicamento)) {
					String message = "Se ha creado el medicamento con el id: " + medicamento.getId();
					request.setAttribute("message", message);
					regresar(request, response, farmacia,session);
				
				}else {
					String message = "No se pudo crear el medicamento";
					request.setAttribute("message", message);
					regresarAgregarMedicamento(request, response, farmacia,session);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				String message = "Ha ocurrido un problema de conexión";
				request.setAttribute("message", message);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}else {
			String message = "Debe tener por lo menos un componente";
			request.setAttribute("message", message);
			regresarAgregarMedicamento(request, response, farmacia,session);
		}
		
	}
	
	protected void agregarComponente(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		String message = "";
		Medicamento medicamento = (Medicamento) session.getAttribute("medicamento");
		
		String id = request.getParameter("componente");
		try {
			Optional<Componente> componente = ComponenteBD.buscar(id);
			
			if(componente.isPresent()) {
				medicamento.agregar(componente.get());
				message = "Componente agregado";
				request.setAttribute("message", message);
				session.setAttribute("medicamento", medicamento);
				regresarAgregarMedicamento(request, response, farmacia,session);
			}else {
				message = "No se encontro el componente a agregar";
				request.setAttribute("message", message);
				regresarAgregarMedicamento(request, response, farmacia,session);
			}
			
		} catch (SQLException | PalabraException e) {
			message = "Ocurrio un probrema al agregar el componente";
			request.setAttribute("message", message);
			regresarAgregarMedicamento(request, response, farmacia,session);
		}
	}

	protected void quitarComponente(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		String message = "";
		Medicamento medicamento = (Medicamento) session.getAttribute("medicamento");
		
		String id = request.getParameter("componente");
		try {
			Optional<Componente> componente = ComponenteBD.buscar(id);
			
			if(componente.isPresent()) {
				medicamento.quitar(componente.get());
				message = "Componente eliminado del medicamento";
				request.setAttribute("message", message);
				session.setAttribute("medicamento", medicamento);
				regresarAgregarMedicamento(request, response, farmacia,session);
			}else {
				message = "No se encontro el componente a eliminar";
				request.setAttribute("message", message);
				regresarAgregarMedicamento(request, response, farmacia,session);
			}
			
		} catch (SQLException | PalabraException e) {
			message = "Ocurrio un probrema al eliminar el componente";
			request.setAttribute("message", message);
			regresarAgregarMedicamento(request, response, farmacia,session);
		}
	}

	protected void agregarComponenteActualizar(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		String message = "";
		Medicamento medicamento = (Medicamento) session.getAttribute("medicamento");
		
		String id = request.getParameter("componente");
		try {
			Optional<Componente> componente = ComponenteBD.buscar(id);
			
			if(componente.isPresent()) {
				medicamento.agregar(componente.get());
				message = "Componente agregado";
				request.setAttribute("message", message);
				session.setAttribute("medicamento", medicamento);
				regresarActualizarMedicamento(request, response, farmacia,session);
			}else {
				message = "No se encontro el componente a agregar";
				request.setAttribute("message", message);
				regresarActualizarMedicamento(request, response, farmacia,session);
			}
			
		} catch (SQLException | PalabraException e) {
			message = "Ocurrio un probrema al agregar el componente";
			request.setAttribute("message", message);
			regresarActualizarMedicamento(request, response, farmacia,session);
		}
	}

	protected void quitarComponenteActualizar(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		String message = "";
		Medicamento medicamento = (Medicamento) session.getAttribute("medicamento");
		
		String id = request.getParameter("componente");
		try {
			Optional<Componente> componente = ComponenteBD.buscar(id);
			
			if(componente.isPresent()) {
				medicamento.quitar(componente.get());
				message = "Componente eliminado del medicamento";
				request.setAttribute("message", message);
				session.setAttribute("medicamento", medicamento);
				regresarActualizarMedicamento(request, response, farmacia,session);
			}else {
				message = "No se encontro el componente a eliminar";
				request.setAttribute("message", message);
				regresarActualizarMedicamento(request, response, farmacia, session);
			}
			
		} catch (SQLException | PalabraException e) {
			message = "Ocurrio un probrema al eliminar el componente";
			request.setAttribute("message", message);
			regresarAgregarMedicamento(request, response, farmacia,session);
		}
	}
	
	protected void agregarComponenteAcualizar(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		String message = "";
		Medicamento medicamento = (Medicamento) session.getAttribute("medicamento");
		
		String id = request.getParameter("componente");
		try {
			Optional<Componente> componente = ComponenteBD.buscar(id);
			
			if(componente.isPresent()) {
				medicamento.agregar(componente.get());
				message = "Componente agregado";
				request.setAttribute("message", message);
				session.setAttribute("medicamento", medicamento);
				regresarActualizarMedicamento(request, response, farmacia,session);
			}else {
				message = "No se encontro el componente a agregar";
				request.setAttribute("message", message);
				regresarActualizarMedicamento(request, response, farmacia,session);
			}
			
		} catch (SQLException | PalabraException e) {
			message = "Ocurrio un probrema al agregar el componente";
			request.setAttribute("message", message);
			regresarActualizarMedicamento(request, response, farmacia,session);
		}
	}

	protected void quitarComponenteAcualizar(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		String message = "";
		Medicamento medicamento = (Medicamento) session.getAttribute("medicamento");
		
		String id = request.getParameter("componente");
		try {
			Optional<Componente> componente = ComponenteBD.buscar(id);
			
			if(componente.isPresent()) {
				medicamento.quitar(componente.get());
				message = "Componente eliminado del medicamento";
				request.setAttribute("message", message);
				session.setAttribute("medicamento", medicamento);
				regresarActualizarMedicamento(request, response, farmacia,session);
			}else {
				message = "No se encontro el componente a eliminar";
				request.setAttribute("message", message);
				regresarActualizarMedicamento(request, response, farmacia,session);
			}
			
		} catch (SQLException | PalabraException e) {
			message = "Ocurrio un probrema al eliminar el componente";
			request.setAttribute("message", message);
			regresarActualizarMedicamento(request, response, farmacia,session);
		}
	}
		
	protected void actualizarMedicamento(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException{
		boolean crear = true;
		String[] message = new String[4];
		for(int i=0; i<message.length; i++)
			message[i] = "";
		Medicamento medicamento = new Medicamento((Medicamento) session.getAttribute("medicamento"));
		
		String nombre = request.getParameter("NombreMedicamento"); //0
		String viaAdministracion = request.getParameter("ViaAdministracion");
		String fecha = request.getParameter("FechaCaducidad");//1
		double precio = -1;
		String precioS = request.getParameter("Precio");
		if(!precioS.equals("")) {
			try {
				precio = Double.parseDouble(precioS);//2
			} catch (NumberFormatException e) {
				message[2] = "No ha ingresado una edad"; 
			}
		}
		
		//reacomodamos fecha
		String[] fechaToken = fecha.split("-");
		String fechaCaducidad = "";
		if(fechaToken.length == 3)
			fechaCaducidad = fechaToken[2] + "/" + fechaToken[1] + "/" + fechaToken[0];
		
		//Intentamos crear la Medicamento
		try {
			if(!nombre.equals(""))
				medicamento.setNombre(nombre.toUpperCase());
		} catch (PalabraException e) {
			if(!viaAdministracion.equals(""))
				message[0] = e.getMessage();
		}
		if(!viaAdministracion.equals("Sin cambios") && !viaAdministracion.equals("")) {
			medicamento.setViaAdministracion(viaAdministracion.toUpperCase());
		}else {
			message[3] = "Escoje una via de administracion valida";
		}
		try {
			if(!fechaCaducidad.equals(""))
				medicamento.setFechaCaducidad(fechaCaducidad.toUpperCase());
		} catch (FechaException e) {
			message[1] = e.getMessage();
		} catch (PalabraException e) {
			message[1] = e.getMessage();
		}
		try {
			if(!precioS.equals(""))
				medicamento.setPrecio(precio);
		} catch (NegativeException e) {
			message[2] = e.getMessage();
		}
			
		for(String s: message) {
			if(!s.equals("")) {
				crear = false;
				break;
			}
		}
		
		if(crear) {
			session.setAttribute("medicamento", medicamento);
			regresarActualizarMedicamento(request, response, farmacia, session);
		}else {
			request.setAttribute("message", message);
			List<String> list = ViaAdministracion.valores();
			request.setAttribute("vias",list);
			request.getRequestDispatcher("GestionMedicamento/ActualizarMedicamento.jsp").forward(request, response);
		}
		
	}

	protected void actualizarMedicamentoContinuar(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		Medicamento medicamento = (Medicamento) session.getAttribute("medicamento");
		
		int cont = 0;
		Iterator<Componente> componentes = medicamento.getComponentes();
		while(componentes.hasNext()) {
			componentes.next();
			cont++;
		}
		
		if(cont>0) {
			try {
				if(MedicamentoBD.actualizar(medicamento)) {
					String message = "Se ha actualizado el medicamento con el id: " + medicamento.getId();
					request.setAttribute("message", message);
					regresar(request, response, farmacia,session);
				
				}else {
					String message = "No se pudo crear el medicamento";
					request.setAttribute("message", message);
					regresarActualizarMedicamento(request, response, farmacia,session);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			String message = "Debe tener por lo menos un componente";
			request.setAttribute("message", message);
			regresarActualizarMedicamento(request, response, farmacia, session);
		}
		
	}
	
	protected void actualizarExistencia(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException {
		Medicamento medicamento = new Medicamento((Medicamento) session.getAttribute("medicamento"));
		String message = "";
		String numS = request.getParameter("NumMedicamentos");
		int num = 0;
		try {
			num = Integer.parseInt(numS);
		} catch (NumberFormatException e) {
			message = "Ingrese un número entero";
		}
		
		num += medicamento.getNumeroMedicamentos();
		
		try {
			medicamento.setNumMedicamentos(num);
		} catch (NegativeException e) {
			message = e.getMessage();
		}
		
		try {
			MedicamentoBD.actualizarExistencia(medicamento);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.setAttribute("message", message);
		session.setAttribute("medicamento", medicamento);
		request.getRequestDispatcher("GestionMedicamento/InfoMedicamento.jsp").forward(request, response);
	}

	protected void eliminarMedicamento(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		Medicamento medicamento = (Medicamento) session.getAttribute("medicamento");
		String message;

		try {
			if(MedicamentoBD.eliminar(medicamento.getId())) {
				message = "Se ha eliminado correctamente al cliente con número de tarjeta: " + medicamento.getId();
				request.setAttribute("message", message);
				regresar(request, response, farmacia,session);
			}else {
				message = "No se pudo eliminar al cliente";
				request.setAttribute("message", message);
				regresar(request, response, farmacia,session);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	//Metodos para gestionar componente

	protected boolean buscarComponente(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia, HttpSession session) throws ServletException, IOException {
		boolean result = false;
		String message = "";
		String id = request.getParameter("id");
		if(id != null) {
			try {
				Optional<Componente> componente = ComponenteBD.buscar(id);
				if(componente.isPresent()) {
					session.setAttribute("componente", componente.get());
					result = true;
				}else {
					String mensaje = "Componente no encontrado";
					request.setAttribute("message", mensaje);
					regresarComponente(request, response, farmacia,session);
				}
			} catch (SQLException | PalabraException e) {
				e.printStackTrace();
				String messages = "Ha ocurrido un problema de conexión";
				request.setAttribute("message", messages);
				request.getRequestDispatcher("index.jsp").forward(request, response);
				
			}
		}else {
			message = "No se pudo buscar al componente";
			request.setAttribute("message", message);
			regresarComponente(request, response, farmacia,session);
		}
		return result;
	}

	protected void regresarComponente(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		try {
			session.setAttribute("componentes", farmacia.getComponentes());
			request.getRequestDispatcher("GestionMedicamento/GestionarComponentes.jsp").forward(request, response);
		} catch (Exception  e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

	protected void nuevoComponente(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		boolean crear = true;
		String message = "";

		String nombre = request.getParameter("NombreComponente");
		Componente componente = null;
		
		try {
			componente = new Componente();
			try {
				componente.setSustancia(nombre.toUpperCase());
			} catch (PalabraException e) {
				message = e.getMessage();
			}
		} catch (SQLException e) {
			
		}
		
		if(!message.equals("")) {
			crear = false;
		}
		
		if(crear) {
			try {
				String mensaje = "";
				
				if(ComponenteBD.guardar(componente)) {
					mensaje = "Se creado correctamente el componente con id: " + componente.getId();
					request.setAttribute("message", mensaje);
					regresarComponente(request, response, farmacia,session);
				}else {
					mensaje = "No se pudo crear el componente";
					request.setAttribute("message", mensaje);
					regresarComponente(request, response, farmacia,session);
				}
				
			} catch (SQLException e) {
				
			}
		}else {
			request.setAttribute("message", message);
			request.getRequestDispatcher("GestionMedicamento/NuevoComponente.jsp").forward(request, response);
		}
		
	}

	protected void actualizarComponente(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException{
		boolean crear = true;
		String message = "";
		
		Componente componente ;
		componente = new Componente((Componente) session.getAttribute("componente"));

		String nombre = request.getParameter("NombreMedicamento");
		
		try {
			if(!nombre.equals(""))
				componente.setSustancia(nombre.toUpperCase());
		} catch (PalabraException e) {
			message = e.getMessage();
		}

		if(!message.equals("")) {
			crear = false;
		}
		
		if(crear) {	
			try {
				String mensaje = "";
				
				if(ComponenteBD.actualizar(componente)) {
					mensaje = "Se actualizaron correctamente los detos del componente con id: " + componente.getId();
					request.setAttribute("message", mensaje);
					regresarComponente(request, response, farmacia,session);
				}else {
					mensaje = "No se pudo actualizar al cliente";
					request.setAttribute("message", mensaje);
					regresarComponente(request, response, farmacia,session);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}else {
			request.setAttribute("message", message);
			request.getRequestDispatcher("GestionMedicamento/ActualizarComponentes.jsp").forward(request, response);
		}
		
	}

	protected void eliminarComponente(HttpServletRequest request, HttpServletResponse response, IFarmacia farmacia,HttpSession session) throws ServletException, IOException {
		Componente componente = (Componente) session.getAttribute("componente");
		String message;

		try {
			if(ComponenteBD.eliminar(componente.getId())) {
				message = "Se ha eliminado correctamente el componente con id: " + componente.getId();
				request.setAttribute("message", message);
				regresarComponente(request, response, farmacia,session);
			}else {
				message = "No se pudo eliminar al cliente";
				request.setAttribute("message", message);
				regresarComponente(request, response, farmacia,session);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			String messages = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", messages);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
	

}
