package gestionClientes.modelo;

import java.sql.SQLException;

import general.exception.*;
import general.modelo.Direccion;
import general.modelo.IDireccion;
import general.modelo.Persona;

public class Cliente extends Persona implements ICliente {
	private Tarjeta tarjeta;

	private final int LENGTH_NUM_TARJETA = 8;
	private final int MAX_CLIENTES = (int) Math.pow(10, LENGTH_NUM_TARJETA);
	
	//Metodos de Cliente
	
	public Cliente() throws SQLException {
		this.tarjeta = new Tarjeta(generarNumTarjeta());
	}
	
	protected Cliente(String numTarjeta, Persona datosPersonales) {
		super(datosPersonales);
		this.tarjeta = new Tarjeta(numTarjeta);
	}
	
	public Cliente(Cliente cliente) throws NegativeException {
		//datos de Tarjeta
		this.tarjeta = new Tarjeta(cliente.getNumTarjeta());
		this.tarjeta.setPuntos(cliente.getPuntos());
		
		//Datos de Persona
		primerNombre = cliente.getPrimerNombre();
		segundoNombre = cliente.getSegundoNombre();
		apellidoPaterno = cliente.getApellidoPaterno();
		apellidoMaterno = cliente.getApellidoMaterno();
		edad = cliente.getEdad();
		numeroTelefono = cliente.getNumeroTelefono();
		//Datos de Direccion
		direccion = new Direccion(cliente.direccion);
	}
	
	public void setPuntos(int puntos) throws NegativeException {
		if(edad>=60 && puntos<40)
			this.tarjeta.setPuntos(40);
		else
			this.tarjeta.setPuntos(puntos);
	}
	
	private String generarNumTarjeta() throws SQLException {
		String numTargeta = "";
		do {
			int numTarjetaI = (int) (Math.random() * MAX_CLIENTES);
			
			if(numTarjetaI >= MAX_CLIENTES)
				numTarjetaI = MAX_CLIENTES - 1;
			
			numTargeta = "" + numTarjetaI;
			
			while(numTargeta.length() < LENGTH_NUM_TARJETA) {
				numTargeta = "0" + numTargeta;
			}
			
		}while(ClienteBD.existe(numTargeta));
		return numTargeta;
		
	}
	
	
	//Metodos de ICliente
	
	@Override
	public String getNumTarjeta() {
		return tarjeta.getNumTarjeta();
	}

	@Override
	public int getPuntos() {
		return tarjeta.getPuntos();
	}

	@Override
	public int getDescuento() {
		int descuento = 0;
		
		if(tarjeta.getPuntos()>=10 && tarjeta.getPuntos()<20)
			descuento = 10;
		if(tarjeta.getPuntos()>=20 && tarjeta.getPuntos()<30)
			descuento = 20;
		if(tarjeta.getPuntos()>=30 && tarjeta.getPuntos()<40)
			descuento = 30;
		if(tarjeta.getPuntos()>=40 && tarjeta.getPuntos()<50)
			descuento = 40;
		if(tarjeta.getPuntos()>=50 && tarjeta.getPuntos()<60)
			descuento = 50;
		if(tarjeta.getPuntos()>=60 && tarjeta.getPuntos()<70)
			descuento = 60;
		if(tarjeta.getPuntos()>=70 && tarjeta.getPuntos()<80)
			descuento = 70;
		if(tarjeta.getPuntos()>=80)
			descuento = 80;
		
		return descuento;
	}

	
	//Metodos de Persona

	@Override
	public String getPrimerNombre() {
		return primerNombre;
	}
	
	@Override
	public String getSegundoNombre() {
		return segundoNombre;
	}
	
	@Override
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}
	
	@Override
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}
	
	@Override
	public int getEdad() {
		return edad;
	}
	
	@Override
	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	@Override
	public IDireccion getDireccion() {
		return direccion;
	}

	public String nombreCompleto() {
		String s = "";
		if(!apellidoPaterno.equals(""))
			s += apellidoPaterno;
		if(!apellidoMaterno.equals(""))
			s += " " + apellidoMaterno;
		if(!primerNombre.equals(""))
			s += " " + primerNombre;
		if(!segundoNombre.equals(""))
			s += " " + segundoNombre;
		return s;
	}
	
}
