package general.exception;

public enum Mensajes {
	PALABRA("Formato invalido"),
	NEGATIVE("No puede ser menor a cero"),
	CARACTER("Caracter invalido"),
	CERO("No puede ser cero"),
	RANGO("Fuera de rango"),
	LENGTH("Número de caracteres invalido"),
	FECHA("Fecha invalida"),
	PRODUCTO("Producto no encontrado");

	private String message;
	
	private Mensajes(String message) {
		this.message = message;
	}
	
	public String getMessage() {return message;}
	
}
