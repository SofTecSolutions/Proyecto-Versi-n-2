package general.exception;

public class NegativeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NegativeException() {
		super(Mensajes.NEGATIVE.getMessage());
		// TODO Auto-generated constructor stub
	}

}
