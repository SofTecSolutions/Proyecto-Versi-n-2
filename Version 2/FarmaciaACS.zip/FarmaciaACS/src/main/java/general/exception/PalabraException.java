package general.exception;

public class PalabraException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PalabraException() {
		super(Mensajes.PALABRA.getMessage());
	}

}
