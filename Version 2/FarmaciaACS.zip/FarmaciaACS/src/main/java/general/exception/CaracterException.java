package general.exception;

public class CaracterException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CaracterException() {
		super(Mensajes.CARACTER.getMessage());
	}
	
}
