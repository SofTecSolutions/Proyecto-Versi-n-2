package general.modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

import general.exception.CaracterException;
import general.exception.CeroException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;

public class PersonaBD {
	
	public static Optional<Persona> buscar(String id) throws SQLException, PalabraException, CaracterException, LengthException, NegativeException, CeroException, RangoException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Persona persona = null;
		
		//Persona
		String primerNombre = "";
		String segundoNombre = "";
		String apellidoPaterno = "";
		String apellidoMaterno = "";
		int edad = 0;
		String numeroTelefono = "";
		String direccionId = "";
		Optional<Direccion> direccion = null;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			comSQL = "select * from persona  where id = '" + id + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				primerNombre = rs.getString("primer_nombre");
				segundoNombre = rs.getString("segundo_nombre");
				apellidoPaterno = rs.getString("apellido_paterno");
				apellidoMaterno = rs.getString("apellido_materno");
				edad = rs.getInt("edad");
				numeroTelefono = rs.getString("numero_telefono");
				direccionId = rs.getString("direccion");
				
				direccion = DireccionBD.buscar(direccionId);
				
				if(direccion.isPresent()) {
					persona = new Persona();
					persona.setPrimerNombre(primerNombre);
					persona.setSegundoNombre(segundoNombre);
					persona.setApellidoPaterno(apellidoPaterno);
					persona.setApellidoMaterno(apellidoMaterno);
					persona.setEdad(edad);
					persona.setNumeroTelefono(numeroTelefono);
					persona.setDireccion(direccion.get());
				}
				
				
			}
			conexion.close();
		}
		
		return Optional.ofNullable(persona);
	}

	public static boolean actualizar(IPersona persona, String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "update persona set primer_nombre = '" + persona.getPrimerNombre() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update persona set segundo_nombre = '" + persona.getSegundoNombre() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update persona set apellido_paterno = '" + persona.getApellidoPaterno() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update persona set apellido_materno = '" + persona.getApellidoMaterno() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update persona set edad = " + persona.getEdad() + " where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update persona set numero_telefono = '" + persona.getNumeroTelefono() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont == 6) {
				if(DireccionBD.actualizar(persona.getDireccion(), id)) {
					respuesta = true;
					conexion.commit();
				}else
					conexion.rollback();
			} else
				conexion.rollback();
			
			conexion.close();
		}
		
		return respuesta;
	}

	public static boolean guardar(IPersona persona, String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			if(DireccionBD.guardar(persona.getDireccion(), id)) {
				st = conexion.createStatement();
				comSQL = "insert into persona values ('" + id + "' , '" + persona.getPrimerNombre() +
						"' , '" + persona.getSegundoNombre() + "' , '" + persona.getApellidoPaterno() 
						+ "' , '" + persona.getApellidoMaterno() + "' , "  + persona.getEdad() 
						+ " , '" + persona.getNumeroTelefono() + "' , '" + id + "');";
				cont += st.executeUpdate(comSQL);

				if(cont == 1) 
					respuesta = true;
			}
			
			conexion.close();
		}
		
		return respuesta;
	}

	public static boolean eliminar(String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion!= null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			comSQL = "delete from persona where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from direccion where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);

			System.out.println("elimino");
			System.out.println(cont);
			if(cont == 1) {
				if(DireccionBD.eliminar(id)) {
					System.out.println("entro");
					conexion.commit();
					respuesta = true;
				}else
					conexion.rollback();
			}else
				conexion.rollback();
			
			conexion.close();
			
		}
		
		return respuesta;
	}
	
}
