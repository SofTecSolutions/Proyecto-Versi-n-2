package general.modelo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import general.exception.CaracterException;
import general.exception.CeroException;
import general.exception.FechaException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;
import gestionClientes.modelo.*;
import gestionMedicamentos.modelo.*;
import gestionVendedores.modelo.*;

public class Farmacia implements IFarmacia{
	private String nombre;
	private String RFC;
	private String numeroTelefono;
	private Direccion direccion;
	private String password;
	private Map<String, Vendedor> vendedores;
	private Map<String, Medicamento> medicamentos;
	private Map<String, Componente> componentes;
	private Map<String, Cliente> clientes;
	
	//Merodos de Farmacia
	
	public Farmacia(){
		this.vendedores = new HashMap<>();
		this.medicamentos = new HashMap<>();
		this.componentes = new HashMap<>();
		this.clientes = new HashMap<>();
	}
	
	public Farmacia(Farmacia farmacia){
		vendedores = new HashMap<>();
		this.medicamentos = new HashMap<>();
		this.componentes = new HashMap<>();
		this.clientes = new HashMap<>();
		this.nombre = farmacia.nombre;
		this.RFC = farmacia.RFC;
		this.numeroTelefono = farmacia.numeroTelefono;
		this.password = farmacia.password;
		this.direccion = new Direccion(farmacia.direccion);
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setRFC(String rfc) {
		this.RFC = rfc;
	}
	
	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setDireccion(Direccion direccion) {
		this.direccion = new Direccion(direccion);
	}

	private void cargarVendedoresCorreo() throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException {
		this.vendedores = new HashMap<>();
		List<Vendedor> vendedores = VendedorBD.buscarVendedores();
		for(Vendedor v: vendedores) {
			this.vendedores.put(v.getCorreo(), v);
		}
	}

	private void cargarVendedores() throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException {
		this.vendedores = new HashMap<>();
		List<Vendedor> vendedores = VendedorBD.buscarVendedores();
		for(Vendedor v: vendedores) {
			this.vendedores.put(v.getNumEmpleado(), v);
		}
	}
	
	private void cargarMedicamentos() throws SQLException, PalabraException, FechaException, NegativeException {
		this.medicamentos = new HashMap<>();
		List<Medicamento> medicamentos = MedicamentoBD.buscarMedicamentos();
		for(Medicamento m: medicamentos) {
			this.medicamentos.put(m.getId(), m);
		}
	}

	private void cargarComponentes() throws SQLException, PalabraException {
		this.componentes = new HashMap<>();
		List<Componente> componentes = ComponenteBD.buscarComponentes();
		for(Componente c: componentes) {
			this.componentes.put(c.getId(), c);
		}
	}

	private void cargarClientes() throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException {
		this.clientes = new HashMap<>();
		List<Cliente> clientes = ClienteBD.buscarClientes();
		for(Cliente c: clientes) {
			this.clientes.put(c.getNumTarjeta(), c);
		}
	}
	
	
	//Metodos Estaticos de Farmacia
	
	
	//Metodos de IFarmacia
	
	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public String getRFC() {
		return RFC;
	}

	@Override
	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	@Override
	public String getPassword() {
		return password;
	}
	
	@Override
	public IDireccion getDireccion() {
		return direccion;
	}
	
	public Optional<IVendedor> obtenerVendedor(String correo, String password) throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException {
		cargarVendedoresCorreo();
		Optional<Vendedor> vendedor = Optional.ofNullable(this.vendedores.get(correo));
		IVendedor result = null;
		
		if(vendedor.isPresent()) {
			if(vendedor.get().getPassword().equals(password)) {
				result = (IVendedor) vendedor.get();
			}
		}
		
		return Optional.ofNullable(result);
	}
	
	public Iterator<IVendedor> getVendedores() throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException{
		cargarVendedores();
		List<IVendedor> vendedores = new ArrayList<IVendedor>();
		for(Vendedor v: this.vendedores.values()) {
			vendedores.add(v);
		}
		return vendedores.iterator();
	}

	@Override
	public Iterator<ICliente> getClientes() throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException {
		cargarClientes();
		List<ICliente> clientes = new ArrayList<ICliente>();
		for(Cliente c: this.clientes.values()) {
			clientes.add(c);
		}
		return clientes.iterator();
	}

	@Override
	public Iterator<IMedicamento> getMedicamentos() throws SQLException, PalabraException, FechaException, NegativeException {
		cargarMedicamentos();
		List<IMedicamento> medicamentos = new ArrayList<IMedicamento>();
		for(Medicamento m: this.medicamentos.values()) {
			medicamentos.add(m);
		}
		return medicamentos.iterator();
	}

	@Override
	public Iterator<IComponente> getComponentes() throws SQLException, PalabraException {
		cargarComponentes();
		List<IComponente> componentes = new ArrayList<IComponente>();
		for(Componente c: this.componentes.values()) {
			componentes.add(c);
		}
		return componentes.iterator();
	}
	
}
