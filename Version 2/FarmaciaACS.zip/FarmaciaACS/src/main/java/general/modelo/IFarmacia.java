package general.modelo;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.Optional;

import general.exception.CaracterException;
import general.exception.CeroException;
import general.exception.FechaException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;
import gestionClientes.modelo.ICliente;
import gestionMedicamentos.modelo.IComponente;
import gestionMedicamentos.modelo.IMedicamento;
import gestionVendedores.modelo.IVendedor;

public interface IFarmacia {
	public String getNombre();
	public String getRFC();
	public String getNumeroTelefono();
	public String getPassword();
	public IDireccion getDireccion();
	public Optional<IVendedor> obtenerVendedor(String correo, String password) throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException;
	public Iterator<IVendedor> getVendedores() throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException;
	public Iterator<ICliente> getClientes() throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException ;
	public Iterator<IMedicamento> getMedicamentos() throws SQLException, PalabraException, FechaException, NegativeException ;
	public Iterator<IComponente> getComponentes() throws SQLException, PalabraException ;
}
