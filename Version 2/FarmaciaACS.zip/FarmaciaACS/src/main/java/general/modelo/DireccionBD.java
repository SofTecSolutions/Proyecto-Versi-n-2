package general.modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

import general.exception.CaracterException;
import general.exception.LengthException;
import general.exception.PalabraException;

public class DireccionBD {

	public static Optional<Direccion> buscar(String id) throws SQLException, PalabraException, CaracterException, LengthException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Direccion direccion = null;
		
		//Direccion 
		String calle = "";
		String numExterno = "";
		String numInterno = "";
		String colonia = "";
		String ciudad = "";
		String estado = "";
		String codigoPostal = "";
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			comSQL = "select * from direccion where id = '" + id + "';";
			rs = st.executeQuery(comSQL);

			while(rs.next()) {
				calle = rs.getString("calle");
				numExterno = rs.getString("num_externo");
				numInterno = rs.getString("num_interno");
				colonia = rs.getString("colonia");
				ciudad = rs.getString("ciudad");
				estado = rs.getString("estado");
				codigoPostal = rs.getString("codigo_postal");

				direccion = new Direccion();
				
				direccion.setCalle(calle);
				direccion.setNumExterior(numExterno);
				direccion.setNumInterior(numInterno);
				direccion.setColonia(colonia);
				direccion.setCiudad(ciudad);
				direccion.setEstado(estado);
				direccion.setCodigoPostal(codigoPostal);
				
				conexion.close();
			}
		}
		
		return Optional.ofNullable(direccion);
	}
	
	public static boolean actualizar(IDireccion direccion, String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "update direccion set calle = '" + direccion.getCalle() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update direccion set num_externo = '" + direccion.getNumExterior() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update direccion set num_interno = '" + direccion.getNumInterior() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update direccion set colonia = '" + direccion.getColonia() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update direccion set ciudad = '" + direccion.getCiudad() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update direccion set estado = '" + direccion.getEstado() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update direccion set codigo_postal = '" + direccion.getCodigoPostal() + "' where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont == 7) {
				respuesta = true;
				conexion.commit();
			} else
				conexion.rollback();
			
			conexion.close();
		}
		
		return respuesta;
	}
	
	public static boolean guardar(IDireccion direccion, String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "insert into direccion values ('" + id + "' , '" + direccion.getCalle() 
					+ "' , '" + direccion.getNumExterior() + "' , '" + direccion.getNumInterior() 
					+ "' , '" + direccion.getColonia() + "' , '" + direccion.getCiudad() 
					+ "' , '" + direccion.getEstado() + "' , '" + direccion.getCodigoPostal() + "');";
			cont += st.executeUpdate(comSQL);

			if(cont == 1) 
				respuesta = true;
		
			conexion.close();
		}
		
		return respuesta;
	}

	public static boolean eliminar(String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion!= null) {
			st = conexion.createStatement();
			comSQL = "delete from direccion where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont == 1)
				respuesta = true;
		
			conexion.close();
			
		}
		
		return respuesta;
	}
	
}
