package general.modelo;

import general.exception.*;

public class Persona {
	protected String primerNombre;
	protected String segundoNombre;
	protected String apellidoPaterno;
	protected String apellidoMaterno;
	protected int edad;
	protected String numeroTelefono;
	protected Direccion direccion;
	
	//Metodos de Persona
	
	public Persona() {
		this.primerNombre = "";
		this.segundoNombre = "";
		this.apellidoPaterno = "";
		this.apellidoMaterno = "";
		this.edad = 0;
		this.numeroTelefono = "";
		this.direccion = new Direccion();
	}
	
	public Persona(Persona persona) {
		this.primerNombre = persona.primerNombre;
		this.segundoNombre = persona.segundoNombre;
		this.apellidoPaterno = persona.apellidoPaterno;
		this.apellidoMaterno = persona.apellidoMaterno;
		this.edad = persona.edad;
		this.numeroTelefono = persona.numeroTelefono;
		this.direccion = new Direccion(persona.direccion);
	}
	
	public void setPrimerNombre(String primerNombre) throws PalabraException {
		if(primerNombre.matches("^[A-ZÁÉÍÓÚÜÑ]{1,50}([\\s][A-ZÁÉÍÓÚÑ]{1,50}){0,9}"))
			this.primerNombre = primerNombre;
		else 
			throw new PalabraException();
	}

	public void setSegundoNombre(String segundoNombre) throws PalabraException {
		if(segundoNombre.matches("^[A-ZÁÉÍÓÚÜÑ]{1,50}([\\s][A-ZÁÉÍÓÚÑ]{1,50}){0,9}") || segundoNombre.matches(""))
			this.segundoNombre = segundoNombre;
		else 
			throw new PalabraException();
	}

	public void setApellidoPaterno(String apellidoPaterno) throws PalabraException {
		if(apellidoPaterno.matches("^[A-ZÁÉÍÓÚÜÑ]{1,50}([\\s][A-ZÁÉÍÓÚÑ]{1,50}){0,9}"))
			this.apellidoPaterno = apellidoPaterno;
		else 
			throw new PalabraException();
	}

	public void setApellidoMaterno(String apellidoMaterno) throws PalabraException {
		if(apellidoMaterno.matches("^[A-ZÁÉÍÓÚÜÑ]{1,50}([\\s][A-ZÁÉÍÓÚÑ]{1,50}){0,9}"))
			this.apellidoMaterno = apellidoMaterno;
		else 
			throw new PalabraException();
	}

	public void setEdad(int edad) throws NegativeException, RangoException {
		if(edad>=18 && edad<=150)
			this.edad = edad;
		else { if (edad<0)
				throw new NegativeException();
			else
				throw new RangoException();}
	}

	public void setNumeroTelefono(String numeroTelefono) throws LengthException, CaracterException {
		if(numeroTelefono.matches("[0-9]{10}"))
			this.numeroTelefono = numeroTelefono;
		else if(numeroTelefono.matches("[0-9]{0,9}") || numeroTelefono.matches("[0-9]{11,}"))
			throw new LengthException();
		else
			throw new CaracterException();
	}
	
	public void setDireccion(Direccion direccion) {
		this.direccion = new Direccion(direccion);
	}
}
