package general.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

import general.exception.CaracterException;
import general.exception.LengthException;
import general.exception.PalabraException;

public class AdminBD {
	
	public static Connection conectar() throws SQLException{
		Connection conexion = null;
		String url;
		String password;
		String usuario;
		
		url = "jdbc:postgresql://localhost:5432/farmacia";
		usuario = "postgres";
		password = "p057gr35";
		
		conexion = DriverManager.getConnection(url, usuario, password);
		
		return conexion;
	}
	
	private static boolean existe() throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			comSQL = "select * from farmacia where id = 'ADMIN';";
			rs = st.executeQuery(comSQL);
			while(rs.next()) {
				cont += 1;
			}
			conexion.close();
		}
		
		if(cont > 0)
			respuesta = true;
		
		return respuesta;
	}
	public static Farmacia cargar() throws SQLException, PalabraException, CaracterException, LengthException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Farmacia farmacia = null;
		
		//Farmacia
		String nombre;
		String RFC;
		String numeroTelefono;
		Optional<Direccion> direccion;
		String password;
		
		if(!existe())
			creaAdmin();
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from farmacia where id = 'ADMIN';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				nombre = rs.getString("nombre");
				RFC = rs.getString("rfc");
				numeroTelefono = rs.getString("numero_telefono");
				password = rs.getString("password");
				
				direccion = DireccionBD.buscar("ADMIN");
				
				if(direccion.isPresent()) {
					farmacia = new Farmacia();
					farmacia.setNombre(nombre);
					farmacia.setNumeroTelefono(numeroTelefono);
					farmacia.setRFC(RFC);
					farmacia.setPassword(password);
					farmacia.setDireccion(direccion.get());
				}
				
			}
			conexion.close();
		}
		
		return farmacia;
	}
	
	private static void creaAdmin() throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "insert into direccion values ('ADMIN' , 'PROLONGACIÓN SAN ISIDRO' , '152' , 'SN' , "
					+ "'SAN LORENZO TEZONCO' , 'ALCALDIA IZTAPALAPA' , 'CDMX' , '09790');";
			st.executeUpdate(comSQL);
			
			comSQL = "insert into farmacia values ('ADMIN' , 'FARMACIA DS'" +
					" , 'FDA230528LSH' , '5558580538' , 'ADMIN' , 'FarmaciaDs.');";
			st.executeUpdate(comSQL);
			
			conexion.close();
		}
	}

}
