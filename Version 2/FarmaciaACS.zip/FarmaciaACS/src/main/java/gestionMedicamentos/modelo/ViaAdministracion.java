package gestionMedicamentos.modelo;

import java.util.Optional;
import java.util.ArrayList;
import java.util.List;

public enum ViaAdministracion {
	ORAL (1), 
	INYECTABLE (2), 
	RECTAL (3), 
	SUBLINGUAL (4), 
	OCULAR (5), 
	OTICA (6), 
	NASAL (7), 
	CUTANEA (8), 
	INHALATORIA (9),
	PRUEBA (10);
	
	private int id;
	
	private ViaAdministracion(int id) {
		this.id = id;
	}
	
	public int getId() {return id;}
	
	public static Optional<ViaAdministracion> getViaAdministracion(int id)
	{
		ViaAdministracion via = null;

	    for(ViaAdministracion v: ViaAdministracion.values())
	    {
	        if(id == v.getId())
	        {
	            via = v;
	            break;
	        }
	    }

	    return Optional.ofNullable(via);
	}
	
	
	public static List<String> valores() {
		List<String> valores = new ArrayList<String>();
		  for(ViaAdministracion v: ViaAdministracion.values())
		    {
		       valores.add(v.name());
		    }
		return valores;
	}
	
}
