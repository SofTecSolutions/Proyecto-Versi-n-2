package gestionMedicamentos.modelo;

public interface IComponente {
	public String getId();
	public String getNombreSustancia();
}
