package gestionMedicamentos.modelo;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import general.exception.*;

public class Medicamento implements IMedicamento {
	private String id;
	private String nombre;
	private String viaAdministracion;
	private String fechaCaducidad;
	private double precio;
	private int numMedicamentos;
	private Map<String, Componente> componentes;

	private final int LENGTH_ID = 3;
	private final int MAX_MEDICAMENTOS = (int) Math.pow(10, LENGTH_ID);
	
	//Metodos de Medicamento
	
	public Medicamento() throws SQLException {
		this.id = generarId();
		this.componentes = new HashMap<>();
		numMedicamentos = 0;
	}
	
	protected Medicamento(String id) {
		this.id = id;
		this.componentes = new HashMap<>();
	}
	
	public Medicamento(Medicamento medicamento) {
		this.id = medicamento.getId();
		this.nombre = medicamento.getNombre();
		this.viaAdministracion = medicamento.getViaAdministracion();
		this.fechaCaducidad = medicamento.getFechaCaducidad();
		this.precio = medicamento.getPrecio();
		this.numMedicamentos = medicamento.getNumeroMedicamentos();
		
		this.componentes = new HashMap<>();
		for(Componente c: medicamento.componentes.values()) {
			componentes.put(c.getId(),new Componente(c));
		}
		
	}

	public void setNombre(String nombre) throws PalabraException {
		if(nombre.matches("^[A-ZÁÉÍÓÚÜÑ0-9\\.]{1,50}([\\s][A-ZÁÉÍÓÚÑ0-9\\.]{1,50}){0,9}"))
			this.nombre = nombre;
		else
			throw new PalabraException();
	}

	public void setViaAdministracion(String viaAdministracion) {
		this.viaAdministracion = viaAdministracion;
	}

	public void setFechaCaducidad(String fechaCaducidad) throws PalabraException, FechaException {
		if(fechaCaducidad.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}")) {
			String[] f = fechaCaducidad.split("/");
			int a, m, d;
			d = Integer.parseInt(f[0]);
			m = Integer.parseInt(f[1]);
			a = Integer.parseInt(f[2]);
			System.out.println(d);
			if(comprobarFecha(d, m, a))
				this.fechaCaducidad = fechaCaducidad;
			else
				throw new FechaException();
		} else
			throw new PalabraException();
	}

	public void setPrecio(double precio) throws NegativeException {
		if(precio >= 0)
			this.precio = precio;
		else
			throw new NegativeException();
	}

	public void setNumMedicamentos(int numMedicamentos) throws NegativeException {
		if(numMedicamentos >= 0)
			this.numMedicamentos = numMedicamentos;
		else
			throw new NegativeException();
	}
	
	public void setComponentes(List<Componente> componentes) {
		this.componentes = new HashMap<>();
		for(Componente c: componentes)
			this.componentes.put(c.getId(),new Componente(c));
	}
	
	public void agregar(Componente componente) {
		this.componentes.put(componente.getId(), componente);
	}

	public void quitar(Componente componente) {
		this.componentes.remove(componente.getId());
	}
	
	protected boolean comprobarFecha(int d, int m, int a) {
		boolean b = true;
		if (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12) {
			if (d >= 1 && d <= 31) {
				if (a <= 0)
					b = false;
			} else
				b = false;
		} else {
			if (m == 4 || m == 6 || m == 9 || m == 11) {
				if (d >= 1 && d <= 30) {
					if (a <= 0)
						b = false;
				} else
					b = false;
			} else {
				if (m == 2) {
					if (a > 0) {
						if ((a % 4 == 0 && a % 100 != 0) || (a % 400 == 0)) {
							if (!(d >= 1 && d <= 29))
								b = false;
						} else {
							if (!(d >= 1 && d <= 28))
								b = false;
						}
					} else
						b = false;
				} else
					b = false;
			}
		}
		System.out.println(b);
		return b;
	}

	private String generarId() throws SQLException {
		String id = "";
		do {
			int idI = (int) (Math.random() * MAX_MEDICAMENTOS);
			
			if(idI >= MAX_MEDICAMENTOS)
				idI = MAX_MEDICAMENTOS - 1;
			
			id = "" + idI;
			
			while(id.length() < LENGTH_ID) {
				id = "0" + id;
			}
			
		} while(MedicamentoBD.existe(id));
		return id;
	}
	
	
	//Metodos de IMedicamento

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public String getViaAdministracion() {
		return viaAdministracion;
	}

	@Override
	public String getFechaCaducidad() {
		return fechaCaducidad;
	}

	@Override
	public double getPrecio() {
		return precio;
	}

	@Override
	public int getNumeroMedicamentos() {
		return numMedicamentos;
	}

	@Override
	public Iterator<Componente> getComponentes() {
		return componentes.values().iterator();
	}
	
	@Override
	public String listaComponentes() {
		int cont = 1;
		String lista = ""; 
		for(Componente c: this.componentes.values()) {
			if(cont == 1) {
				lista += c.getNombreSustancia();
				cont++;
			}else {
				lista += ", " + c.getNombreSustancia();
			}
		}
		
		return lista;
	}
	
}
