package gestionMedicamentos.modelo;

import java.sql.SQLException;

import general.exception.PalabraException;

public class Componente implements IComponente {
	private String id;
	private String sustancia;

	private final int LENGTH_ID = 2;
	private final int MAX_COMPONENTES = (int) Math.pow(10, LENGTH_ID);
	
	//Metodos de Componente
	
	public Componente() throws SQLException {
		this.id = generarId();
	}
	
	protected Componente(String id) {
		this.id = id;
	}
	
	public Componente(Componente componente) {
		this.id = componente.getId();
		this.sustancia = componente.getNombreSustancia();
	}

	public void setSustancia(String sustancia) throws PalabraException {
		if(sustancia.matches("^[A-ZÁÉÍÓÚÜÑ]{1,50}([\\s][A-ZÁÉÍÓÚÑ]{1,50}){0,9}"))
			this.sustancia = sustancia;
		else
			throw new PalabraException();
	}
	
	private String generarId() throws SQLException {
		String id = "";
		do {
			int idI = (int) (Math.random() * MAX_COMPONENTES);
			
			if(idI >= MAX_COMPONENTES)
				idI = MAX_COMPONENTES - 1;
			
			id = "" + idI;
			
			while(id.length() < LENGTH_ID) {
				id = "0" + id;
			}
			
		} while(ComponenteBD.existe(id));
		return id;
	}
	
	
	//Metodos de IComponente
	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getNombreSustancia() {
		return sustancia;
	}
	
}