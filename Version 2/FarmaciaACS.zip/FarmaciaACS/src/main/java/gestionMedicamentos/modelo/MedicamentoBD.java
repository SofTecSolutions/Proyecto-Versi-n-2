package gestionMedicamentos.modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import general.exception.FechaException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.modelo.AdminBD;
import gestionVentas.modelo.Producto;

public class MedicamentoBD {

	public static boolean existe(String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			try {
				st = conexion.createStatement();
				comSQL = "select * from medicamento where id = '" + id + "';";
				rs = st.executeQuery(comSQL);
				while(rs.next()) {
					cont += 1;
				}
			}catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					conexion.close();
				} catch (SQLException e2) {
					// TODO: handle exception
				}
			}
		}
		
		if(cont > 0)
			respuesta = true;
		
		return respuesta;
	}

	public static Optional<Medicamento> buscar(String id) throws SQLException, PalabraException, FechaException, NegativeException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Medicamento medicamento = null;
		
		String nombre = "";
		String viaAdministracion = "";
		String fechaCaducidad = "";
		double precio = 0;
		int numMedicamentos = 0;
		List<Componente> componentes = null;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from medicamento where id = '" + id + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				id = rs.getString("id");
				nombre = rs.getString("nombre");
				viaAdministracion = rs.getString("via_administracion");
				fechaCaducidad = rs.getString("fecha_caducidad");
				precio = rs.getDouble("precio");
				
				medicamento = new Medicamento(id);
				medicamento.setNombre(nombre);
				medicamento.setViaAdministracion(viaAdministracion);
				medicamento.setFechaCaducidad(fechaCaducidad);
				medicamento.setPrecio(precio);
			}
			
			if(medicamento!=null) {
				comSQL = "select * from medicamento_existencia where id = '" + medicamento.getId() + "';";
				rs = st.executeQuery(comSQL);
			
				while(rs.next()) {
					numMedicamentos = rs.getInt("num_medicamentos");

					medicamento.setNumMedicamentos(numMedicamentos);
				}
				
				componentes = ComponenteBD.buscarComponentes(id);
				medicamento.setComponentes(componentes);
				
			}
			
			
			conexion.close();
		}
		
		return Optional.ofNullable(medicamento);
	}
	public static boolean actualizar(Medicamento medicamento) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "update medicamento set nombre = '" + medicamento.getNombre() + "' where id = '" + medicamento.getId() + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update medicamento set fecha_caducidad = '" + medicamento.getFechaCaducidad() + "' where id = '" + medicamento.getId() + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update medicamento set via_administracion = '" + medicamento.getViaAdministracion() + "' where id = '" + medicamento.getId() + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update medicamento set precio = " + medicamento.getPrecio() + " where id = '" + medicamento.getId() + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from medicamento_componente where id_medicamento = '" + medicamento.getId() + "';";
			cont += st.executeUpdate(comSQL);
			
			Iterator<Componente> componentes = medicamento.getComponentes();
			while(componentes.hasNext()) {
				Componente c = componentes.next();
				
				comSQL = "insert into medicamento_componente values ('" + medicamento.getId() + "' , '" + c.getId() + "');";
				cont += st.executeUpdate(comSQL);
				
			}
			
			if(cont >= 1) {
				conexion.commit();
				respuesta = true;
			}else
				conexion.rollback();
		
			conexion.close();
		}
		
		return respuesta;
	}
	
	public static boolean actualizarExistencia(Medicamento medicamento) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "update medicamento_existencia set num_medicamentos = " + medicamento.getNumeroMedicamentos() + " where id = '" + medicamento.getId() + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont >= 1) {
				conexion.commit();
				respuesta = true;
			}else
				conexion.rollback();
		
			conexion.close();
		}
		
		return respuesta;
	}
	
	public static boolean eliminar(String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion!= null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();

			comSQL = "delete from venta_producto where id_medicamento = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from medicamento_componente where id_medicamento = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from medicamento_existencia where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from medicamento where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			
			if(cont >= 1 ) {
				respuesta = true;
				conexion.commit();
			}else
				conexion.rollback();
			
			conexion.close();
			
		}
		
		return respuesta;
	}
	
	public static boolean guardar(Medicamento medicamento) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
				st = conexion.createStatement();
				comSQL = "insert into medicamento values ('" + medicamento.getId() + "' , '" + medicamento.getNombre() + 
						"' , '" + medicamento.getViaAdministracion() + "' , '" + medicamento.getFechaCaducidad() + 
						"' , " + medicamento.getPrecio() + ");";
				cont += st.executeUpdate(comSQL);
				
				comSQL = "insert into medicamento_existencia values ('" + medicamento.getId() + "' , " + medicamento.getNumeroMedicamentos() + ");";
				cont += st.executeUpdate(comSQL);
				
				Iterator<Componente> componentes = medicamento.getComponentes();
				while(componentes.hasNext()) {
					Componente c = componentes.next();
					
					comSQL = "insert into medicamento_componente values ('" + medicamento.getId() + "' , '" + c.getId() + "');";
					cont += st.executeUpdate(comSQL);
					
				}
				
				if(cont >= 1) 
					respuesta = true;
				
				conexion.close();
		}
		
		return respuesta;
	}
	
	public static List<Medicamento> buscarMedicamentos() throws SQLException, PalabraException, FechaException, NegativeException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Medicamento> medicamentos = new ArrayList<Medicamento>();
		Medicamento medicamento = null;
		
		String id = "";
		String nombre = "";
		String viaAdministracion = "";
		String fechaCaducidad = "";
		double precio = 0;
		int numMedicamentos = 0;
		List<Componente> componentes = null;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from medicamento;";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				id = rs.getString("id");
				nombre = rs.getString("nombre");
				viaAdministracion = rs.getString("via_administracion");
				fechaCaducidad = rs.getString("fecha_caducidad");
				precio = rs.getDouble("precio");
				
				medicamento = new Medicamento(id);
				medicamento.setNombre(nombre);
				medicamento.setViaAdministracion(viaAdministracion);
				medicamento.setFechaCaducidad(fechaCaducidad);
				medicamento.setPrecio(precio);
				
				componentes = ComponenteBD.buscarComponentes(id);
				medicamento.setComponentes(componentes);
				
				medicamentos.add(medicamento);
			}
			
			for(Medicamento m: medicamentos) {
				comSQL = "select * from medicamento_existencia where id = '" + m.getId() + "';";
				rs = st.executeQuery(comSQL);
			
				while(rs.next()) {
					numMedicamentos = rs.getInt("num_medicamentos");

					m.setNumMedicamentos(numMedicamentos);
				}
			}
			
			conexion.close();
		}
		
		return medicamentos;
	}

	public static List<Producto> buscarProductos(String id) throws FechaException, SQLException, PalabraException, NegativeException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Producto> productos = new ArrayList<Producto>();
		Producto producto = null;
		Medicamento medicamento = null;
		
		String idC = "";
		int numMedicamentos = 0;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from venta_producto where folio = '" + id + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				idC = rs.getString("id_medicamento");
				numMedicamentos = rs.getInt("cantidad");
				
				medicamento = buscar(idC).get();
				
				producto = new Producto(medicamento); 
				
				for(int i=1; i<=numMedicamentos;i++)
					producto.aumentar();
				
				productos.add(producto);
			}
			
			conexion.close();
		}
		
		return productos;
	}
	
}
