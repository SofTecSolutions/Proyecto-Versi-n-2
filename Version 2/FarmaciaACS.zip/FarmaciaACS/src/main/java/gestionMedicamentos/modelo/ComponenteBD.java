package gestionMedicamentos.modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import general.exception.PalabraException;
import general.modelo.AdminBD;

public class ComponenteBD {

	public static boolean existe(String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			try {
				st = conexion.createStatement();
				comSQL = "select * from componente where id = '" + id + "';";
				rs = st.executeQuery(comSQL);
				while(rs.next()) {
					cont += 1;
				}
			}catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					conexion.close();
				} catch (SQLException e2) {
					// TODO: handle exception
				}
			}
		}
		
		if(cont > 0)
			respuesta = true;
		
		return respuesta;
	}

	public static Optional<Componente> buscar(String id) throws SQLException, PalabraException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Componente componente = null;
		
		String sustancia = "";
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from componente where id = '" + id + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				sustancia = rs.getString("sustancia");
				
				componente = new Componente(id);
				componente.setSustancia(sustancia);
				
			}
			conexion.close();
		}
		
		return Optional.ofNullable(componente);
	}

	public static Optional<Componente> buscarSustancia(String nombre) throws SQLException, PalabraException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Componente componente = null;
		
		String id = "";
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from componente where sustancia = '" + nombre + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				id = rs.getString("id");
				
				componente = new Componente(id);
				componente.setSustancia(nombre);
				
			}
			conexion.close();
		}
		
		return Optional.ofNullable(componente);
	}
	
	public static boolean actualizar(Componente componente) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "update componente set sustancia = '" + componente.getNombreSustancia() + "' where id = '" + componente.getId() + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont == 1) {
				conexion.commit();
				respuesta = true;
			}else
				conexion.rollback();
		
			conexion.close();
		}
		
		return respuesta;
	}
	
	public static boolean eliminar(String id) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion!= null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "delete from medicamento_componente where id_componente = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from componente where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			
			if(cont >= 1 ) {
				respuesta = true;
				conexion.commit();
			}else
				conexion.rollback();
			
			conexion.close();
			
		}
		
		return respuesta;
	}
	
	public static boolean guardar(Componente componente) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
				st = conexion.createStatement();
				comSQL = "insert into componente values ('" + componente.getId() + "' , '" + componente.getNombreSustancia() + "');";
				cont += st.executeUpdate(comSQL);

				if(cont == 1) 
					respuesta = true;
				
				conexion.close();
		}
		
		return respuesta;
	}
	
	public static List<Componente> buscarComponentes() throws SQLException, PalabraException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Componente> componentes = new ArrayList<Componente>();
		Componente componente = null;
		
		String id = "";
		String sustancia = "";
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from componente;";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				id = rs.getString("id");
				sustancia = rs.getString("sustancia");
				
				componente = new Componente(id);
				componente.setSustancia(sustancia);
				
				componentes.add(componente);
				
			}
			conexion.close();
		}
		
		return componentes;
	}

	public static List<Componente> buscarComponentes(String id) throws SQLException, PalabraException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Componente> componentes = new ArrayList<Componente>();
		Componente componente = null;
		
		String idC = "";
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from medicamento_componente where id_medicamento = '" + id + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				idC = rs.getString("id_componente");
				
				componente = buscar(idC).get();
				
				componentes.add(componente);
			}
			
			conexion.close();
		}
		
		return componentes;
	}
	
}
