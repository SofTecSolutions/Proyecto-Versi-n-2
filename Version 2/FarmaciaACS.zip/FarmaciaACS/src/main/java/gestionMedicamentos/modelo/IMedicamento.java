package gestionMedicamentos.modelo;

import java.util.Iterator;

public interface IMedicamento {
	public String getId();
	public String getNombre();
	public String getViaAdministracion();
	public String getFechaCaducidad();
	public double getPrecio();
	public int getNumeroMedicamentos();
	public Iterator<Componente> getComponentes();
	public String listaComponentes();
}
