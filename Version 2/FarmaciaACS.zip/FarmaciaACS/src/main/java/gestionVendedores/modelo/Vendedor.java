package gestionVendedores.modelo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import general.exception.*;
import general.modelo.Direccion;
import general.modelo.IDireccion;
import general.modelo.Persona;
import gestionVentas.modelo.IVenta;
import gestionVentas.modelo.Venta;
import gestionVentas.modelo.VentaBD;

public class Vendedor extends Persona implements IVendedorCompleto{
	private String numEmpleado;
	private double sueldo;
	private Usuario usuario = null;
	private List<Venta> ventas;
	
	private final int LENGTH_NUM_EMPLEADO = 5;
	private final int MAX_EMPLEADOS = (int) Math.pow(10, LENGTH_NUM_EMPLEADO);
	
	//Metodos de Vendedor
	public Vendedor() throws SQLException {
		this.numEmpleado = generarNumEmpleado();
		this.ventas = new ArrayList<Venta>();
	}
	
	protected Vendedor(String numEmpleado, String correo, Persona datosPersonales) {
		super(datosPersonales);
		this.numEmpleado = numEmpleado;
		this.usuario = new Usuario(correo);
		this.ventas = new ArrayList<Venta>();
	}
	
	public Vendedor(Vendedor vendedor) {
		//Datos de Persona
		primerNombre = vendedor.getPrimerNombre();
		segundoNombre = vendedor.getSegundoNombre();
		apellidoPaterno = vendedor.getApellidoPaterno();
		apellidoMaterno = vendedor.getApellidoMaterno();
		edad = vendedor.getEdad();
		numeroTelefono = vendedor.getNumeroTelefono();
		//Datos de Direccion
		direccion = new Direccion(vendedor.direccion);
		//Datos de Vendedor
		numEmpleado = vendedor.getNumEmpleado();
		sueldo = vendedor.getSueldo();
		usuario =  new Usuario(vendedor.usuario);
		this.ventas = new ArrayList<Venta>();
	}
	
	public void setSueldo(double sueldo) throws NegativeException {
		if(sueldo>=0)
			this.sueldo = sueldo;
		else
			throw new NegativeException();
	}
	
	public void setPassword(String password) throws LengthException {
		this.usuario.setPassword(password);
	}
	
	private String generarNumEmpleado() throws SQLException {
		String numEmpleado = "";
		int numEmpleadoI = 0;
		do {
			numEmpleadoI = (int) (Math.random() * MAX_EMPLEADOS);
			
			if(numEmpleadoI >= MAX_EMPLEADOS)
				numEmpleadoI = MAX_EMPLEADOS - 1;
			
			numEmpleado = "" + numEmpleadoI;
			
			while(numEmpleado.length() < LENGTH_NUM_EMPLEADO) {
				numEmpleado = "0" + numEmpleado;
			}
			
		} while (VendedorBD.existe(numEmpleado));
		return numEmpleado;
	}
	
	public void generarCorreo() throws SQLException, LengthException {
		String correo = primerNombre.toLowerCase().replaceAll(" ", ".") + "." + apellidoPaterno.toLowerCase().replaceAll(" ", ".");
		if(VendedorBD.existeCorreo(correo + "@farmaciads.com")) {
			correo += "." + apellidoMaterno.toLowerCase().replaceAll(" ", ".");
			if(VendedorBD.existeCorreo(correo + "@farmaciads.com")) {
				correo += "." + numEmpleado;
			}
		}
		this.usuario = new Usuario(correo + "@farmaciads.com");
		this.usuario.setPassword("LSH" + numEmpleado);
	}
	
	public void cargarVentas() throws SQLException, FechaException, PalabraException, NegativeException {
		List<Venta> ventas = VentaBD.buscarVentas(numEmpleado);
		this.ventas = new ArrayList<Venta>();
		
		for(Venta v: ventas) {
			this.ventas.add(new Venta(v));
		}
		
	}
	
	
	//Metodos de IVendedorCompleto
	
	@Override
	public Iterator<IVenta> getVentas() throws SQLException, FechaException, PalabraException, NegativeException{
		cargarVentas();
		List<IVenta> ventas = new ArrayList<IVenta>();
		for(Venta v: this.ventas)
			ventas.add(v);
		return ventas.iterator();
	}

	@Override
	public String getPassword() {
		return this.usuario.getPassword();
	}
	
	
	//Metodos de IVendedor
	
	@Override
	public String getNumEmpleado() {
		return numEmpleado;
	}

	@Override
	public double getSueldo() {
		return sueldo;
	}

	@Override
	public String getCorreo() {
		return usuario.getCorreo();
	}
	
	
	//Metodos de IPersona
	
	@Override
	public String getPrimerNombre() {
		return primerNombre;
	}
	
	@Override
	public String getSegundoNombre() {
		return segundoNombre;
	}
	
	@Override
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}
	
	@Override
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}
	
	@Override
	public int getEdad() {
		return edad;
	}
	
	@Override
	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	@Override
	public IDireccion getDireccion() {
		return direccion;
	}

	@Override
	public String nombreCompleto() {
		String s = "";
		if(!apellidoPaterno.equals(""))
			s += apellidoPaterno;
		if(!apellidoMaterno.equals(""))
			s += " " + apellidoMaterno;
		if(!primerNombre.equals(""))
			s += " " + primerNombre;
		if(!segundoNombre.equals(""))
			s += " " + segundoNombre;
		return s;
	}
	
}
