package gestionVendedores.modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import general.exception.CaracterException;
import general.exception.CeroException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;
import general.modelo.AdminBD;
import general.modelo.Persona;
import general.modelo.PersonaBD;

public class VendedorBD {

	public static boolean existe(String numEmpleado) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			comSQL = "select * from vendedor where num_empleado = '" + numEmpleado + "';";
			rs = st.executeQuery(comSQL);
			while(rs.next()) {
				cont += 1;
			}
			conexion.close();
		}
		
		if(cont > 0)
			respuesta = true;
		
		return respuesta;
	}
	
	public static Optional<Vendedor> buscar(String numEmpleado) throws SQLException, NegativeException, LengthException, PalabraException, CaracterException, CeroException, RangoException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Vendedor vendedor = null;
		
		//Vendedor
		double sueldo = 0;
		String correo = "";
		String password = "";
		String personaId = "";
		Optional<Persona> persona = null;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from vendedor where num_empleado = '" + numEmpleado + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				sueldo = rs.getDouble("sueldo");
				correo = rs.getString("correo");
				password = rs.getString("password");
				personaId = rs.getString("persona");
				
				persona = PersonaBD.buscar(personaId);
				
				if(persona.isPresent()) {
					vendedor = new Vendedor(numEmpleado, correo, persona.get());
					vendedor.setSueldo(sueldo);
					vendedor.setPassword(password);
				}
				
			}
			conexion.close();
		}
		
		return Optional.ofNullable(vendedor);
	}
	
	public static boolean actualizar(Vendedor vendedor) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "update vendedor set sueldo = " + vendedor.getSueldo() + " where num_empleado = '" + vendedor.getNumEmpleado() + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update vendedor set correo = '" + vendedor.getCorreo() + "' where num_empleado = '" + vendedor.getNumEmpleado() + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update vendedor set password = '" + vendedor.getPassword()+ "' where num_empleado = '" + vendedor.getNumEmpleado() + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont == 3) {
				if(PersonaBD.actualizar(vendedor, vendedor.getNumEmpleado())) {
					respuesta = true;
					conexion.commit();
				}else
					conexion.rollback();
			}else
				conexion.rollback();
		
			conexion.close();
		}
		
		return respuesta;
	}
	
	public static boolean eliminar(String numEmpleado) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion!= null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();

			comSQL = "delete from vendedor_venta where num_empleado = '" + numEmpleado + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from vendedor where num_empleado = '" + numEmpleado + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from persona where id = '" + numEmpleado + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from direccion where id = '" + numEmpleado + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont >= 3 ) {
				respuesta = true;
				conexion.commit();
			}else
				conexion.rollback();
			
			conexion.close();
			
		}
		
		return respuesta;
	}
	
	public static boolean existeCorreo(String correo) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
				st = conexion.createStatement();
				comSQL = "select * from vendedor where correo = '" + correo + "';";
				rs = st.executeQuery(comSQL);
				while(rs.next()) {
					cont += 1;
				}
				
				conexion.close();
		}
		
		if(cont > 0)
			respuesta = true;
		
		return respuesta;
	}
	
	public static boolean guardar(Vendedor vendedor) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
				if(PersonaBD.guardar(vendedor, vendedor.getNumEmpleado())) {
					st = conexion.createStatement();
					comSQL = "insert into vendedor values ('" + vendedor.getNumEmpleado() + "' , " + vendedor.getSueldo() +
							" , '" + vendedor.getCorreo() + "' , '" + vendedor.getPassword() + "' , '"  + vendedor.getNumEmpleado() + "');";
					cont += st.executeUpdate(comSQL);

					if(cont == 1) 
						respuesta = true;
				}
				
				conexion.close();
		}
		
		return respuesta;
	}
	
	public static List<Vendedor> buscarVendedores() throws SQLException, LengthException, NegativeException, PalabraException, CaracterException, CeroException, RangoException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Vendedor> vendedores = new ArrayList<Vendedor>();
		Vendedor vendedor = null;
		
		//Vendedor
		String numEmpleado = "";
		double sueldo = 0;
		String correo = "";
		String password = "";
		String personaId = "";
		Optional<Persona> persona = null;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
				st = conexion.createStatement();
				
				comSQL = "select * from vendedor;";
				rs = st.executeQuery(comSQL);
				
				while(rs.next()) {
					numEmpleado = rs.getString("num_empleado");
					sueldo = rs.getDouble("sueldo");
					correo = rs.getString("correo");
					password = rs.getString("password");
					personaId = rs.getString("persona");
					
					persona = PersonaBD.buscar(personaId);
					
					if(persona.isPresent()) {
						vendedor = new Vendedor(numEmpleado, correo, persona.get());
						vendedor.setSueldo(sueldo);
						vendedor.setPassword(password);
						
						vendedores.add(vendedor);
					}
					
				}
				conexion.close();
		}
		
		return vendedores;
	}
	
}
