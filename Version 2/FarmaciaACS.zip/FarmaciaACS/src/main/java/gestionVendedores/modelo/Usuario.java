package gestionVendedores.modelo;

import general.exception.*;

public class Usuario {
	private String correo;
	private String password;

	protected Usuario(String correo) {
		this.correo = correo;
	}
	
	public Usuario(Usuario usuario) {
		correo = usuario.correo;
		password = usuario.password;
	}
	
	protected void setPassword(String password) throws LengthException {
		if(password.matches(".{8,}"))
			this.password = password;
		else
			throw new LengthException();
	}
	
	protected String getCorreo() {
		return correo;
	}
	
	protected String getPassword() {
		return password;
	}
	
}
